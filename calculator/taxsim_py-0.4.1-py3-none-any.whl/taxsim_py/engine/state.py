"""Shared expressions used by state tax calculators."""


from __future__ import annotations
from collections.abc import Iterable, Mapping
from typing import Any

from contextvars import ContextVar

import polars as pl

from taxsim_py.behavior import BehaviorProfile, TAXSIM_BEHAVIOR
from taxsim_py.engine.inputs import separate_divisor
from taxsim_py.engine.schema import PARAMETERS_ROOT, load_yaml, resolve_year

_PRE1987_PARAMS = load_yaml(PARAMETERS_ROOT / "national" / "pre1987.yaml")
_SOCSEC_PARAMS = load_yaml(PARAMETERS_ROOT / "national" / "state_socsec.yaml")
_PAYROLL_PARAMS = load_yaml(PARAMETERS_ROOT / "national" / "payroll_tax.yaml")
_ADJUSTMENT_PARAMS = load_yaml(PARAMETERS_ROOT / "national" / "state_adjustments.yaml")
_CAPITAL_GAINS_PARAMS = load_yaml(PARAMETERS_ROOT / "national" / "capital_gains.yaml")


def with_default(
    df: pl.DataFrame | pl.LazyFrame, column: str, default: Any = 0.0
) -> pl.DataFrame | pl.LazyFrame:
    """Add a column with a default value when it is absent."""
    return with_defaults(df, (column,), default)


def with_defaults(
    df: pl.DataFrame | pl.LazyFrame, columns: Iterable[str], default: Any = 0.0
) -> pl.DataFrame | pl.LazyFrame:
    """Add each absent column with a default value, resolving the schema once."""
    present = set(df.collect_schema().names())
    missing = [column for column in columns if column not in present]
    if not missing:
        return df
    return df.with_columns(pl.lit(default).alias(column) for column in missing)


def by_filing_status(values: Mapping[str, float]) -> pl.Expr:
    """Select a numeric value using the ``filing_status`` column."""
    expression = pl.lit(None, dtype=pl.Float64)
    for status, value in values.items():
        expression = (
            pl.when(pl.col("filing_status") == status)
            .then(pl.lit(float(value)))
            .otherwise(expression)
        )
    return expression


# Set while a state calculator builds its expressions: TAXSIM mode reproduces the
# 2026 build, which weights a table that falls as income rises the wrong way round.
REVERSE_FALLING_TABLE_WEIGHTS: ContextVar[bool] = ContextVar("reverse_falling_table_weights", default=False)


def _blend(weight: pl.Expr, lower_value: pl.Expr | float, upper_value: pl.Expr | float, rising: pl.Expr) -> pl.Expr:
    proper = (1 - weight) * lower_value + weight * upper_value
    if not REVERSE_FALLING_TABLE_WEIGHTS.get():
        return proper
    return pl.when(rising).then(proper).otherwise(weight * lower_value + (1 - weight) * upper_value)


def interpolate_table(income: pl.Expr, rows: list[list[float]]) -> pl.Expr:
    """Interpolate a TAXSIM ``tablki`` table of ``[threshold, value]`` rows.

    Below the first threshold the first value applies and at or above the
    last threshold the last value applies; in between, TAXSIM's weighting
    between the neighbouring rows is used.
    """
    if any(isinstance(value, pl.Expr) for row in rows for value in row):
        return _interpolate_table_by_row(income, rows)
    thresholds = [float(row[0]) for row in rows[:-1]]
    values = [float(row[1]) for row in rows]
    last = len(thresholds)
    count = pl.lit(pl.Series(thresholds, dtype=pl.Float64)).search_sorted(income, side="right").cast(pl.Int64)
    threshold_series = pl.lit(pl.Series(thresholds, dtype=pl.Float64))
    value_series = pl.lit(pl.Series(values, dtype=pl.Float64))
    lower_index = (count - 1).clip(0, last - 1)
    upper_index = count.clip(0, last - 1)
    lower_threshold = threshold_series.gather(lower_index)
    upper_threshold = threshold_series.gather(upper_index)
    lower_value = value_series.gather((count - 1).clip(0, last))
    upper_value = value_series.gather(count.clip(0, last))
    weight = (income - lower_threshold) / (upper_threshold - lower_threshold)
    between = _blend(weight, lower_value, upper_value, upper_value > lower_value)
    return (
        pl.when(count == 0)
        .then(pl.lit(values[0]))
        .when(count >= last)
        .then(pl.lit(values[-1]))
        .otherwise(between)
    )


def _interpolate_table_by_row(income: pl.Expr, rows: list[list]) -> pl.Expr:
    """`interpolate_table` for thresholds or values that vary by row."""
    thresholds = [row[0] for row in rows[:-1]]
    values = [row[1] for row in rows]
    expression = pl.lit(values[-1]) if not isinstance(values[-1], pl.Expr) else values[-1]
    for index in range(len(thresholds) - 1, -1, -1):
        upper_threshold = thresholds[index]
        upper_value = values[index]
        if index == 0:
            below = upper_value if isinstance(upper_value, pl.Expr) else pl.lit(upper_value)
        else:
            lower_threshold = thresholds[index - 1]
            lower_value = values[index - 1]
            weight = (income - lower_threshold) / (upper_threshold - lower_threshold)
            below = _blend(
                weight,
                lower_value,
                upper_value,
                pl.lit(upper_value) > lower_value if not isinstance(upper_value, pl.Expr) else upper_value > lower_value,
            )
        expression = pl.when(income < upper_threshold).then(below).otherwise(expression)
    return expression


def unemployment_total() -> pl.Expr:
    """Unemployment compensation, preferring the spouse split when larger."""
    return pl.max_horizontal(pl.col("ui"), pl.col("pui") + pl.col("sui"))


def federal_capital_gain_in_agi(year: int, flate: float = 1.0) -> pl.Expr:
    """Net capital gain in federal AGI (TAXSIM `comnew(6)`) in the state frame's (deflated) dollars."""
    if year <= 1986:
        return pl.col("pre1987_capgn")
    loss_limit = float(resolve_year(_CAPITAL_GAINS_PARAMS["net_capital_loss_limit"], year))
    return pl.max_horizontal(pl.col("stcg") + pl.col("ltcg"), -loss_limit / flate / separate_divisor())


def dividend_input_adjustment() -> float:
    """Amount TAXSIM adds to the dividend input."""
    return float(_ADJUSTMENT_PARAMS["household_income_dividend_adjustment"])


def household_income(behavior: BehaviorProfile = TAXSIM_BEHAVIOR) -> pl.Expr:
    """TAXSIM's household-income total (`data(159)`) from raw inputs.

    Sums positive wages, dividends, pensions, unemployment compensation,
    Social Security benefits, transfers, interest, self-employment, business
    and S corporation income, other property income and positive net capital
    gains, plus TAXSIM's input adjustments (in statutory mode only the
    dividend one). Other non-property income is not included, nor (in
    TAXSIM mode) self-employment income.
    """
    record_adjustment = float(_ADJUSTMENT_PARAMS["household_income_record_adjustment"])
    if behavior.drop_household_income_record_adjustment:
        # TAXSIM's leftover $1 from the first record's input.
        record_adjustment = 0.0
    self_employment = (
        pl.col("psemp") + pl.col("ssemp") if behavior.include_self_employment_in_household_income else pl.lit(0.0)
    )
    return self_employment + (
        pl.col("pwages").clip(0, None)
        + pl.col("swages").clip(0, None)
        + pl.col("dividends")
        + dividend_input_adjustment()
        + pl.col("pensions")
        + unemployment_total()
        + pl.col("gssi")
        + pl.col("transfers")
        + pl.col("intrec")
        + pl.col("pbusinc") + pl.col("pprofinc") + pl.col("sbusinc") + pl.col("sprofinc") + pl.col("scorp")
        + pl.col("otherprop")
        + (pl.col("stcg") + pl.col("ltcg")).clip(0, None)
        + record_adjustment
    )


def allocate_pensions(pensions: pl.Expr, age: pl.Expr | float) -> tuple[pl.Expr, pl.Expr]:
    """TAXSIM `penalloc`: pension income to the taxpayer and spouse by age.

    A joint return gives it all to the spouse at or over `age` when the other is under, half each when
    both or neither are; any other return gives it all to the taxpayer. A joint spouse of unknown age is 40.
    """
    sage = pl.when(pl.col("sage") == 0).then(40.0).otherwise(pl.col("sage").cast(pl.Float64))
    joint = pl.col("filing_status") == "married_joint"
    taxpayer_old, spouse_old = pl.col("page") >= age, sage >= age
    primary = pl.when(~joint).then(pensions).when(taxpayer_old & ~spouse_old).then(pensions).when(~taxpayer_old & spouse_old).then(0.0).otherwise(pensions / 2)
    return primary, pensions - primary


def social_security_full_retirement_age(year: int) -> pl.Expr:
    """TAXSIM `ssfra`: the full retirement age from the primary taxpayer's birth year (year less age).

    65 through 1954, 66 and 10 to 50 months for 1955-1959 (as TAXSIM types them), 67 from 1960, and 65 with no age.
    """
    birth = year - pl.col("page")
    table = {1955: 66.1666, 1956: 66.3333, 1957: 66.5, 1958: 66.6666, 1959: 66.8333}
    expr = pl.when(birth >= 1960).then(67.0).otherwise(65.0)
    for ibirth, value in table.items():
        expr = pl.when(birth == ibirth).then(value).otherwise(expr)
    return pl.when(pl.col("page") > 0).then(expr).otherwise(65.0)


def optimal_split(amount: pl.Expr, income_primary: pl.Expr, income_spouse: pl.Expr) -> tuple[pl.Expr, pl.Expr]:
    """TAXSIM `optalloc`: split `amount` between spouses to cut the larger of their incomes first."""
    gap = (income_primary - income_spouse).abs()
    to_larger = pl.min_horizontal(amount, gap)
    shared = (amount - to_larger) / 2
    primary_larger = income_primary > income_spouse
    primary = pl.when(gap <= 0).then(amount / 2).otherwise(pl.when(primary_larger).then(to_larger).otherwise(0.0) + shared)
    spouse = pl.when(gap <= 0).then(amount / 2).otherwise(pl.when(primary_larger).then(0.0).otherwise(to_larger) + shared)
    positive = amount > 0
    return pl.when(positive).then(primary).otherwise(0.0), pl.when(positive).then(spouse).otherwise(0.0)


def higher_earner_share(income: pl.Expr) -> pl.Expr:
    """The higher earner's share of joint income: their wages plus half the rest."""
    return pl.max_horizontal(pl.col("pwages"), pl.col("swages")) + (income - pl.col("wages")) / 2.0


def federal_dividend_exclusion_limit(year: int, behavior: BehaviorProfile = TAXSIM_BEHAVIOR) -> pl.Expr:
    """The 1960-1986 federal dividend exclusion limit by filing status."""
    if year == 1979 and not behavior.apply_1979_dividend_exclusion:
        # TAXSIM reads the 1979 exclusion from an input it never sets.
        return pl.lit(0.0)
    return by_filing_status(
        {status: resolve_year(amounts, year) for status, amounts in _PRE1987_PARAMS["dividend_exclusion"].items()}
    )


def dividend_exclusion_addback(year: int, behavior: BehaviorProfile = TAXSIM_BEHAVIOR) -> pl.Expr:
    """Federal dividend exclusion that states add back to federal AGI (`divexc`).

    Before 1987 this is the dividends (plus interest in 1981) excluded from
    federal AGI; from 1987 there is no exclusion and the addback is zero.
    """
    if year >= 1987:
        return pl.lit(0.0)
    excluded = pl.col("dividends") + dividend_input_adjustment()
    if year == 1981:
        excluded = excluded + pl.col("intrec")
    return pl.min_horizontal(excluded, federal_dividend_exclusion_limit(year, behavior)).clip(0, None)


def split_agi(
    agi: pl.Expr, exclude_primary: pl.Expr | float = 0.0, exclude_spouse: pl.Expr | float = 0.0, projection_factor: float = 1.0
) -> tuple[pl.Expr, pl.Expr]:
    """TAXSIM `splitagi`: each spouse's own income on a joint return, the rest shared equally.

    `agi` is the combined income before the exclusions. Pensions and Social Security go to the spouse
    aged 55 or over (half each when both or neither are), business income to its earner (with each
    spouse's own self-employment tax half deducted), unemployment by `sui`.

    In a projected state-law year (`projection_factor` not 1) TAXSIM keeps the spouse's self-employment input
    (`d(216)`) undeflated while the other inputs are deflated, so the taxpayer's share is the deflated total less the
    undeflated spouse amount (the same quirk Delaware has inline).
    """
    sage = pl.when(pl.col("sage") == 0).then(40.0).otherwise(pl.col("sage").cast(pl.Float64))
    ui_total = pl.max_horizontal(pl.col("ui"), pl.col("pui") + pl.col("sui"))
    sui_part = pl.col("sui")
    pui_part = ui_total - sui_part
    pension_ss = pl.col("pensions") + pl.col("taxable_social_security")
    husband_old, wife_old = pl.col("page") >= 55, sage >= 55
    pent = pl.when(husband_old & ~wife_old).then(pension_ss).when(~husband_old & wife_old).then(0.0).otherwise(pension_ss / 2)
    pens = pension_ss - pent
    seih = pl.col("psemp") + pl.col("pbusinc") + pl.col("pprofinc")
    seis = pl.col("ssemp") + pl.col("sbusinc") + pl.col("sprofinc")
    secah = pl.col("payroll_setax_primary") / 2
    secas = pl.col("payroll_setax_secondary") / 2
    if projection_factor != 1.0:
        secah = secah / projection_factor
        secas = secas / projection_factor
        seih = seih + pl.col("ssemp") - pl.col("ssemp") * projection_factor
        seis = seis - pl.col("ssemp") + pl.col("ssemp") * projection_factor
    tinc = pl.col("pwages") + seih + pui_part - exclude_primary + pent
    sinc = pl.col("swages") + seis + sui_part - exclude_spouse + pens
    cinc = 0.5 * (agi - tinc - sinc + secah + secas)
    return tinc + cinc - secah, sinc + cinc - secas


def allocate_pension(total: pl.Expr, minimum_age: float) -> tuple[pl.Expr, pl.Expr]:
    """TAXSIM `penalloc`: a pension split between the spouses on a joint return.

    All of it goes to the spouse at or over `minimum_age` when only one is;
    otherwise it is split evenly. Everyone else keeps all of it. A missing
    spouse age counts as 40.
    """
    sage = pl.when(pl.col("sage") == 0).then(40.0).otherwise(pl.col("sage").cast(pl.Float64))
    primary_old = pl.col("page") >= minimum_age
    spouse_old = sage >= minimum_age
    primary = (
        pl.when(primary_old & ~spouse_old).then(total)
        .when(~primary_old & spouse_old).then(0.0)
        .otherwise(total / 2)
    )
    primary = pl.when(pl.col("mstat") == 2).then(primary).otherwise(total)
    return primary, total - primary


def net_earnings_by_spouse(behavior: BehaviorProfile = TAXSIM_BEHAVIOR) -> tuple[pl.Expr, pl.Expr]:
    """TAXSIM `comnew(205)` and `comnew(206)`: each spouse's wages plus 92.35% of self-employment income."""
    from taxsim_py.engine.payroll_tax import payroll_items

    earnings = []
    for names in payroll_items(behavior):
        wage = pl.col(names[0]).clip(0, None)
        self_employed = pl.sum_horizontal(pl.col(name).clip(0, None) for name in names[1:])
        earnings.append(wage + 0.9235 * self_employed)
    return earnings[0], earnings[1]


def earned_minimum(year: int) -> pl.Expr:
    """TAXSIM `earnmin`: the lower earner's wages plus net business income on a joint return, else the taxpayer's.

    Net business income is positive items times .9235 from 1990 (all of it before).
    """
    factor = 0.9235 if year >= 1990 else 1.0

    def net(wages: str, *items: str) -> pl.Expr:
        return pl.col(wages).clip(0, None) + factor * pl.sum_horizontal(pl.col(i).clip(0, None) for i in items)

    primary = net("pwages", "psemp", "pbusinc", "pprofinc")
    secondary = net("swages", "ssemp", "sbusinc", "sprofinc")
    return pl.when(pl.col("filing_status") == "married_joint").then(pl.min_horizontal(primary, secondary)).otherwise(primary)


def phaseout_steps(steps: pl.Expr, behavior: "BehaviorProfile") -> pl.Expr:
    """Whole steps of a phase-out: the count rounded up.

    TAXSIM's helpers `ceil` and `rup` only round when an option (`extnd(88)`) is set, which it
    never is, so its phase-outs fall continuously (`round_up_phaseout_steps`).
    """
    return steps.ceil() if behavior.round_up_phaseout_steps else steps


def tier_values(value: pl.Expr, uppers: list[float], *columns: list[float], strict: bool = False) -> list[pl.Expr]:
    """Values from the first tier whose upper bound is at least `value` (the last tier beyond).

    With `strict`, the first tier whose upper bound exceeds `value` (TAXSIM `tablk`).
    """
    side = "right" if strict else "left"
    position = pl.lit(pl.Series(uppers, dtype=pl.Float64)).search_sorted(value, side=side)
    index = position.cast(pl.Int64).clip(0, len(uppers) - 1)
    return [pl.lit(pl.Series(column, dtype=pl.Float64)).gather(index) for column in columns]


def checkpoint(df: pl.DataFrame, **expressions: pl.Expr) -> tuple[pl.DataFrame, list[pl.Expr]]:
    """Store expressions as columns and return references to them.

    Later formulas then read the stored column instead of repeating the
    expression, which keeps expression trees small.
    """
    df = df.with_columns(**expressions)
    return df, [pl.col(name) for name in expressions]


# `force_itemize` column: True or False when the itemize choice is forced
# (the federal-state resolver runs both), null when it is not.
FORCE_ITEMIZE = "force_itemize"
# True on the pass that forces itemizing, where TAXSIM zeroes the federal zero bracket amount.
ZERO_BRACKET_ZEROED = "zero_bracket_zeroed"


def federal_zero_bracket() -> pl.Expr:
    """TAXSIM `comnew(3)`: the standard deduction, 0 on the pass that forces itemizing."""
    return pl.when(pl.col(ZERO_BRACKET_ZEROED).fill_null(False)).then(0.0).otherwise(pl.col("standard_deduction"))


def _forced() -> pl.Expr:
    return pl.col(FORCE_ITEMIZE).cast(pl.Boolean)


def itemize_choice(natural: pl.Expr) -> pl.Expr:
    """The forced itemize choice where set, otherwise `natural`."""
    return pl.when(_forced().is_null()).then(natural).otherwise(_forced())


def forced_itemized() -> pl.Expr:
    """True where itemizing is forced."""
    return _forced().fill_null(False)


def forced_standard() -> pl.Expr:
    """True where the standard deduction is forced."""
    return _forced().not_().fill_null(False)


def pre1987_federal_itemizing(year: int) -> tuple[pl.Expr, pl.Expr, pl.Expr]:
    """Federal itemizing through 1986 (`comnew(30)`, `comnew(26)`, `comnew(3)`).

    Returns the gross itemized total, whether the federal return itemizes, and
    the zero bracket amount, the latter two as the pre-1987 federal
    calculator reports them.
    """
    gross = (
        pl.col("state_sales_or_income_tax_ded") + pl.col("proptax") + pl.col("otheritem")
        + pl.col("mortgage") + pl.col("charity_cash")
    )
    return gross, pl.col("pre1987_itemizes"), pl.col("pre1987_zbr")


def taxsim_socsec(
    year: int, setax: pl.Expr, addmed: pl.Expr | None = None, behavior: BehaviorProfile = TAXSIM_BEHAVIOR
) -> pl.Expr:
    """Payroll tax as TAXSIM's `socsec` reports it to states.

    Employee FICA on each spouse's wages (joint returns) or on total wages,
    plus self-employment tax and, from 2013, the additional Medicare tax.
    Wages above the Social Security base pay Medicare tax up to the Medicare
    base (TAXSIM: without limit in every year). `year` is the state law
    year; wages are the (deflated) input columns.
    """
    rate = float(resolve_year(_SOCSEC_PARAMS["rate"], year))
    ceiling = float(resolve_year(_SOCSEC_PARAMS["wage_ceiling"], year))
    above = float(_SOCSEC_PARAMS["rate_above_ceiling"])
    medicare_ceiling = (
        float(resolve_year(_PAYROLL_PARAMS["hi_wage_base"], year)) if behavior.cap_medicare_in_state_payroll_deduction else None
    )

    def fica(wages: pl.Expr) -> pl.Expr:
        medicare_wages = wages if medicare_ceiling is None else pl.min_horizontal(wages, pl.lit(medicare_ceiling))
        return pl.min_horizontal(wages, pl.lit(ceiling)) * rate + (medicare_wages - ceiling).clip(0, None) * above

    pw = pl.col("pwages").clip(0, None)
    sw = pl.col("swages").clip(0, None)
    total = pl.when(pl.col("filing_status") == "married_joint").then(fica(pw) + fica(sw)).otherwise(fica(pw + sw))
    total = total + setax
    if year >= 2013 and addmed is not None:
        total = total + addmed
    return total


_DETAIL_NAMES = {
    "agi": "state_adjusted_gross_income",
    "exemptions": "state_exemptions",
    "standard_deduction": "state_standard_deduction",
    "itemized_deductions": "state_itemized_deductions",
    "taxable_income": "state_taxable_income",
    "property_credit": "state_property_credit",
    "child_care_credit": "state_child_and_dependent_care_credit",
    "eic": "state_earned_income_tax_credit",
    "credits": "state_total_credits",
    "rate": "state_marginal_rate",
}


def with_state_detail(df: pl.DataFrame | pl.LazyFrame, **values: pl.Expr | float) -> pl.DataFrame | pl.LazyFrame:
    """Set the state's detail outputs (TAXSIM's `/calc/` block, `idtl=2`).

    Keywords are `agi`, `exemptions`, `standard_deduction`,
    `itemized_deductions`, `taxable_income`, `property_credit`,
    `child_care_credit`, `eic`, `credits` and `rate` (the bracket rate as a
    fraction), each the final value the TAXSIM routine leaves in that
    variable, in the law year's dollars. Outputs not given are 0.
    """
    unknown = set(values) - set(_DETAIL_NAMES)
    if unknown:
        raise ValueError(f"Unknown state detail outputs: {sorted(unknown)}")
    return df.with_columns(
        (value if isinstance(value, pl.Expr) else pl.lit(float(value))).cast(pl.Float64).alias(_DETAIL_NAMES[name])
        for name, value in values.items()
    )
