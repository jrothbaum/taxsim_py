"""Iowa individual income tax calculator."""


from __future__ import annotations
import polars as pl

from taxsim_py.calculators.federal_pre1987 import PRE1987_PARAMS
from taxsim_py.engine.brackets import bracket_rate, bracket_tax
from taxsim_py.engine.inputs import aged_count, files_head_of_household, files_joint, files_separate, files_single, separate_divisor, taxpayer_count
from taxsim_py.engine.schema import PARAMETERS_ROOT, YearParams, load_yaml
from taxsim_py.engine.state import (
    split_agi,
    federal_dividend_exclusion_limit,
    by_filing_status,
    forced_standard,
    higher_earner_share,
    interpolate_table,
    unemployment_total,
    with_state_detail,
)
from taxsim_py.behavior import BehaviorProfile, TAXSIM_BEHAVIOR
from taxsim_py.engine.state_extrapolation import deflate_for_extrapolation, resolve_state_year

IA_PARAMS = load_yaml(PARAMETERS_ROOT / "states" / "ia" / "income_tax.yaml")
_STATUSES = ["single", "married_joint", "married_separate", "head_of_household"]


def compute_ia_tax(df: pl.DataFrame, year: int, behavior: BehaviorProfile = TAXSIM_BEHAVIOR) -> pl.DataFrame:
    effective_year, flate = resolve_state_year(year, behavior, IA_PARAMS)
    p = YearParams(IA_PARAMS, effective_year)

    df = df.with_columns(
        ia_sep=separate_divisor(),
        ia_taxpayers=taxpayer_count(),
    )

    # Self-employment tax is not deflated in projected years.
    df = df.with_columns(ia_setax=pl.col("payroll_setax"))

    df = deflate_for_extrapolation(df, flate)

    threshold = p.value("itemized_limitation_threshold")
    index = p.num("itemized_limitation_index")
    if isinstance(threshold, dict):
        phas92 = by_filing_status({s: float(v) * index for s, v in threshold.items()})
    else:
        phas92 = float(threshold) * index / pl.col("ia_sep")

    # --- AGI ---
    df = df.with_columns(ia_agi=pl.col("agi") + 0.5 * pl.col("ia_setax"))
    # Social Security: federal taxable benefits out; through 2013 Iowa's own
    # partial taxation in.
    ss_p = p["social_security_base"]
    pha = (
        pl.when(files_joint()).then(float(ss_p["joint"]))
        .when(files_separate()).then(float(ss_p["married_separate"]))
        .otherwise(float(ss_p["single"]))
    )
    df = df.with_columns(ia_agi=pl.col("ia_agi") - pl.col("taxable_social_security"), ia_addph=pl.lit(0.0))
    if effective_year <= 2013:
        half = 0.5 * pl.col("gssi")
        income = pl.col("ia_agi")
        if not behavior.add_back_half_self_employment_tax_before_iowa_social_security_per_statute:
            # TAXSIM measures the benefits' taxable share on income before it adds back half the self-employment tax.
            income = income - 0.5 * pl.col("ia_setax")
        ssb = pl.min_horizontal(0.5 * (half + income.clip(0, None) - pha).clip(0, None), half)
        if p.in_effect("social_security_phaseout_share"):
            ssb = ssb * (1 - p.num("social_security_phaseout_share"))
        ssb = pl.when(pl.col("gssi") > 0).then(ssb).otherwise(0.0)
        df = df.with_columns(ia_agi=pl.col("ia_agi") + ssb)
    # The two-earner deduction also comes after the Social Security step.
    if 1982 <= effective_year <= 1984:
        p87 = YearParams(PRE1987_PARAMS, effective_year)
        rate_2e = p87.num("two_earner_deduction_rate")
        cap_2e = p87.num("two_earner_deduction_cap")
        lesser_wage = pl.min_horizontal(pl.col("pwages"), pl.col("swages")).clip(0, None)
        twoded = pl.when(files_joint()).then(
            (rate_2e * lesser_wage).clip(0, cap_2e)
        ).otherwise(0.0)
        df = df.with_columns(ia_agi=pl.col("ia_agi") + twoded)
    # TAXSIM adds the dividend and interest exclusion back after the Social Security step.
    if p.in_effect("dividend_interest_exclusion_per_taxpayer"):
        fed_excl = federal_dividend_exclusion_limit(effective_year, behavior)
        divexc = pl.min_horizontal(pl.col("dividends") + pl.col("intrec"), fed_excl)
        own_cap = (pl.col("dividends") + pl.col("intrec")).clip(0, p.num("dividend_interest_exclusion_per_taxpayer") * pl.col("ia_taxpayers"))
        df = df.with_columns(ia_agi=pl.col("ia_agi") + divexc - own_cap)
    # The reportable benefits: half of the lesser of the benefits and income (federal AGI less the taxable
    # benefits) over $32,000 on a joint return, $25,000 on any other.
    base = pl.when(files_joint()).then(float(ss_p["joint"])).otherwise(float(ss_p["single"]))
    income = pl.col("agi") - pl.col("taxable_social_security")
    df = df.with_columns(
        ia_addph=pl.when(pl.col("gssi") > 0).then(0.5 * pl.min_horizontal(pl.col("gssi"), (income - base).clip(0, None))).otherwise(0.0)
    )
    # Pension exclusion (1995+), when a taxpayer is 55 or older.
    if effective_year >= 1995:
        cap = p.num("pension_exclusion")
        age_55 = (pl.col("page") >= 55) | (pl.col("sage") >= 55)
        penexc = pl.when(age_55).then(pl.min_horizontal(pl.col("ia_taxpayers") * cap, pl.col("pensions"))).otherwise(0.0)
    else:
        penexc = pl.lit(0.0)
    if p.in_effect("retirement_exclusion"):
        pe = p.value("retirement_exclusion")
        eligible = (pl.col("page") >= float(pe["minimum_age"])) | (pl.col("sage") >= float(pe["minimum_age"]))
        cap = float(pe["cap_per_taxpayer"]) * pl.col("ia_taxpayers")
        penexc = pl.when(eligible).then(pl.min_horizontal(cap, pl.col("pensions"))).otherwise(0.0)
    df = df.with_columns(ia_penexc=penexc, ia_agi=pl.col("ia_agi") - penexc)
    ui_total = unemployment_total()
    if p.in_effect("unemployment_addback_per_taxpayer"):
        df = df.with_columns(ia_agi=pl.col("ia_agi") + pl.min_horizontal(ui_total, p.num("unemployment_addback_per_taxpayer") * pl.col("ia_taxpayers")))

    fedded = pl.col("fiitax").clip(0, None)
    if effective_year >= 2022:
        fedded = (pl.col("fiitax") - pl.col("addmed")).clip(0, None)  # Additional Medicare tax is not income tax
    if effective_year <= 2022 and not behavior.deduct_iowa_federal_tax_after_refundable_credits:
        # TAXSIM deducts tax before the refundable credits: regular tax, AMT and NIIT less the child care and
        # child credits it applied.
        # The child credits it takes off are the nonrefundable and the refundable amounts, which cancel when
        # the nonrefundable one is negative (it is not floored).
        # 2021: the build holds the whole (fully refundable) child tax credit in both of the credit variables.
        child_credits = (pl.col("odc") + pl.col("actc")) * (2.0 if effective_year == 2021 else 1.0)
        fedded = (pl.col("pre1987_taxbc") if effective_year <= 1986 else pl.col("regular_tax")) + pl.col("payroll_setax") - pl.col("ccc") - child_credits - pl.col("addmed")
    if not p.value("federal_tax_deduction"):
        fedded = pl.lit(0.0)
    dedbus = p.num("qbi_deduction_share") * pl.col("qbi_deduction") if effective_year >= 2019 else pl.lit(0.0)

    # --- Standard deduction ---
    pct = p.num("standard_deduction_pct")
    cap_single = p.num("standard_deduction_cap", "single")
    cap_joint = p.num("standard_deduction_cap", "joint_or_hoh")
    is_joint = files_joint()
    gets_single_cap = pl.col("filing_status").is_in(["single", "married_separate"])
    stded = pl.when(gets_single_cap).then(
        (pct * pl.col("ia_agi")).clip(0, cap_single)
    ).otherwise((pct * pl.col("ia_agi")).clip(0, cap_joint))
    if p.value("conforms_to_federal_standard_deduction"):
        stded = pl.col("standard_deduction")
    df = df.with_columns(ia_stded=stded)

    # --- Itemized deduction ---
    # Federal gross itemized deductions less the state tax deduction (before
    # 1987, the itemized inputs).
    if effective_year <= 1986:
        salt_capped_plus_mortgage = pl.col("proptax") + pl.col("otheritem") + pl.col("mortgage") + pl.col("state_sales_or_income_tax_ded")
    else:
        salt_capped_plus_mortgage = pl.col("salt_capped") + pl.col("mortgage")
    df = df.with_columns(ia_xitded=(salt_capped_plus_mortgage - pl.col("state_sales_or_income_tax_ded")).clip(0, None))
    over_thr = (pl.col("ia_agi") > phas92) & (1991 <= effective_year <= 2017) & pl.col("itemizes")
    df = df.with_columns(
        ia_xitded=pl.when(over_thr)
        .then((pl.col("itemized_deduction") - pl.col("state_sales_or_income_tax_ded") * pl.col("itemized_deduction") / salt_capped_plus_mortgage.clip(1e-9, None)).clip(0, None))
        .otherwise(pl.col("ia_xitded"))
    )
    if 2018 <= effective_year <= 2019:
        deduc1 = pl.col("proptax") + pl.col("otheritem") + pl.col("mortgage")
        dlim1 = p["itemized_phaseout_rate"] * (pl.col("ia_agi") - phas92).clip(0, None)
        dlim2 = p["itemized_phaseout_cap_rate"] * deduc1
        dedphs = pl.min_horizontal(dlim1, dlim2)
        df = df.with_columns(ia_xitded=(deduc1 - dedphs).clip(0, None))
    if effective_year >= 2020:
        # TAXSIM counts property tax and mortgage interest only.
        taxsim_itemized = pl.col("proptax") + pl.col("mortgage")
        df = df.with_columns(
            ia_xitded=salt_capped_plus_mortgage if behavior.include_state_taxes_in_iowa_itemized_deduction_from_2020 else taxsim_itemized
        )

    df = df.with_columns(ia_xitded=pl.when(forced_standard()).then(0.0).otherwise(pl.col("ia_xitded")))

    df = df.with_columns(ia_deduc=pl.max_horizontal(pl.col("ia_stded"), pl.col("ia_xitded")))

    # --- Taxable income --- Half of self-employment tax is already in
    # AGI, and the whole amount is added again.
    df = df.with_columns(
        ia_yad=pl.col("ia_agi") + pl.col("ia_setax") - fedded - dedbus,
        ia_taxinc=(pl.col("ia_agi") + pl.col("ia_setax") - fedded - dedbus - pl.col("ia_deduc")
                   # 2025 on: Iowa starts from federal taxable income, which is already
                   # net of the federal senior deduction.
                   - (pl.col("senior_deduction") if effective_year >= 2025 else 0.0)
                   ).clip(0, None),
    )

    # --- Joint returns may file combined: each spouse on their own share ---
    agih = higher_earner_share(pl.col("ia_agi"))
    if not behavior.split_iowa_joint_income_by_wages_only:
        agih, agiw = split_agi(pl.col("ia_agi"), 0.0, 0.0, flate)
    else:
        agiw = pl.col("ia_agi") - agih
    is_mfc = is_joint & (pl.col("ia_agi") > 0) & pl.lit(bool(p.value("combined_return_allowed")))
    stded_h_general = (pct * pl.col("ia_agi")).clip(0, cap_single)
    xitdh = pl.when(pl.col("ia_agi") != 0).then(pl.col("ia_xitded") * agih / pl.col("ia_agi")).otherwise(0.0)
    xitdw = pl.col("ia_xitded") - xitdh
    dedh_general = pl.when(stded_h_general >= xitdw).then(stded_h_general).otherwise(xitdh)
    if not behavior.split_iowa_joint_income_by_wages_only:
        # The 2026 build takes each spouse's larger of the standard deduction and their share of the itemized deduction.
        dedh_general = pl.max_horizontal(stded_h_general, xitdh)
    dedw_general = pl.max_horizontal(stded_h_general, xitdw)
    # The 2026 TAXSIM build splits the federal tax without the self-employment tax and adds that tax back
    # only through 1986.
    split_fedded = fedded if behavior.add_back_iowa_self_employment_tax_twice else fedded - pl.col("ia_setax")
    setax_again = pl.col("ia_setax") if behavior.add_back_iowa_self_employment_tax_twice else pl.lit(0.0)
    feddh = pl.when(pl.col("ia_agi") != 0).then(split_fedded * agih / pl.col("ia_agi")).otherwise(0.0)
    feddw = split_fedded - feddh
    agiw_positive = is_mfc & (agiw > 0)
    # The qualified business income deduction is shared half each; TAXSIM splits it by each spouse's share of the
    # net self-employment earnings (all to the taxpayer when there is none).
    dedbus_h = dedbus_w = 0.5 * dedbus
    if not behavior.split_iowa_joint_income_by_wages_only:
        se_h = (pl.col("psemp") + pl.col("pbusinc") + pl.col("pprofinc")).clip(0, None)
        se_w = (pl.col("ssemp") + pl.col("sbusinc") + pl.col("sprofinc")).clip(0, None)
        share_h = pl.when(se_h + se_w > 0).then(se_h / (se_h + se_w)).otherwise(1.0)
        dedbus_h, dedbus_w = dedbus * share_h, dedbus * (1.0 - share_h)
    taxinh = (
        pl.when(agiw_positive)
        .then((agih - dedh_general + 0.25 * setax_again - feddh - dedbus_h).clip(0, None))
        .when(is_mfc)
        .then(pl.col("ia_taxinc"))
        .otherwise(pl.lit(0.0))
    )
    taxinw = (
        pl.when(agiw_positive)
        .then((agiw - dedw_general + 0.25 * setax_again - feddw - dedbus_w).clip(0, None))
        .otherwise(pl.lit(0.0))
    )
    df = df.with_columns(ia_taxinh=taxinh, ia_taxinw=taxinw, ia_agi_higher_earner=agih, ia_agi_lower_earner=agiw)

    # --- Tax ---
    aif = p.num("bracket_inflation")
    if p.in_effect("taxsim_bracket_inflation") and not behavior.use_iowa_2020_bracket_inflation_per_statute:
        aif = p.num("taxsim_bracket_inflation")
    table = p.value("brackets")
    statax = bracket_tax(pl.col("ia_taxinc") / aif, table) * aif
    single_rate = bracket_rate(pl.col("ia_taxinc") / aif, table)
    if p.in_effect("brackets_by_status"):
        schedules = p.value("brackets_by_status")
        statax = pl.when(is_joint).then(bracket_tax(pl.col("ia_taxinc"), schedules["joint"])).otherwise(
            bracket_tax(pl.col("ia_taxinc"), schedules["other"])
        )
        single_rate = pl.when(is_joint).then(bracket_rate(pl.col("ia_taxinc"), schedules["joint"])).otherwise(
            bracket_rate(pl.col("ia_taxinc"), schedules["other"])
        )
    df = df.with_columns(ia_statax=statax)

    if effective_year <= 1986:
        taxinh2 = pl.when(is_mfc).then(
            (pl.col("ia_agi_higher_earner") - dedh_general + pl.col("ia_setax") * pl.col("ia_agi_higher_earner") / pl.col("ia_agi").clip(1e-9, None) - split_fedded * pl.col("ia_agi_higher_earner") / pl.col("ia_agi").clip(1e-9, None)).clip(0, None)
        ).otherwise(pl.lit(0.0))
        taxinw2 = pl.when(is_mfc).then(
            (pl.col("ia_agi_lower_earner") - dedw_general + pl.col("ia_setax") * pl.col("ia_agi_lower_earner") / pl.col("ia_agi").clip(1e-9, None) - split_fedded * pl.col("ia_agi_lower_earner") / pl.col("ia_agi").clip(1e-9, None)).clip(0, None)
        ).otherwise(pl.lit(0.0))
        stath = bracket_tax(taxinh2 / aif, table) * aif
        statw = bracket_tax(taxinw2 / aif, table) * aif
        df = df.with_columns(
            ia_statax=pl.when(is_mfc).then(pl.min_horizontal(pl.col("ia_statax"), stath + statw)).otherwise(pl.col("ia_statax"))
        )
        split_rate = bracket_rate(taxinw2 / aif, table)
    else:
        stath = bracket_tax(pl.col("ia_taxinh") / aif, table) * aif
        statw = bracket_tax(pl.col("ia_taxinw") / aif, table) * aif
        df = df.with_columns(ia_statj=pl.col("ia_statax"))
        if effective_year >= 2019:
            df = df.with_columns(ia_stath=stath, ia_statw=statw, ia_sepcmb=is_mfc & (stath + statw < pl.col("ia_statax")))
        df = df.with_columns(
            ia_statax=pl.when(is_mfc).then(pl.min_horizontal(pl.col("ia_statax"), stath + statw)).otherwise(pl.col("ia_statax"))
        )
        split_rate = bracket_rate(pl.col("ia_taxinw") / aif, table)
    rate_expr = pl.when(is_mfc).then(split_rate).otherwise(single_rate)

    # --- Alternate Tax --- (never single)
    exy_other = p.num("no_tax_income_limit", "other")
    not_single = pl.col("filing_status") != "single"
    if p.in_effect("alternate_tax_rate"):
        rate_alt = p.num("alternate_tax_rate")
        if effective_year <= 1997:
            altax = (pl.col("ia_agi") - exy_other).clip(0, None) * rate_alt
        else:
            subtr = pl.lit(exy_other)
            if effective_year >= 2007:
                subtr = pl.when(aged_count() > 0).then(p.num("alternate_tax_aged_floor")).otherwise(subtr)
            altax = (pl.col("ia_agi") + pl.col("ia_penexc") + pl.col("ia_addph") - subtr).clip(0, None) * rate_alt
        df = df.with_columns(
            ia_statax=pl.when(not_single).then(pl.min_horizontal(pl.col("ia_statax"), altax)).otherwise(pl.col("ia_statax"))
        )
    if effective_year >= 2021 and p.in_effect("alternate_tax_rate"):
        # From 2021 the alternate tax and the AMT are applied to the joint tax and to each spouse's separate tax; the
        # lower of the joint tax and the two spouses' sum is used. A joint return's alternate tax is shared between the
        # spouses in proportion to their income, and each spouse's tax is limited to its share.
        agi_h, agi = pl.col("ia_agi_higher_earner"), pl.col("ia_agi")
        share_h = (altax * agi_h / agi.clip(1e-9, None)).clip(0, None)
        share_w = (altax - share_h).clip(0, None)
        joint_tax = pl.min_horizontal(pl.col("ia_statj"), altax)
        tax_h, tax_w = pl.min_horizontal(stath, share_h), pl.min_horizontal(statw, share_w)
        whole_tax = pl.col("ia_statax")

        def amt_ia(itemized, standard, taxinc, property_tax, base_tax, status: str) -> pl.Expr:
            rate = p.num("amt_rate")
            floor = float(p["amt_exclusion_base_by_status"][status])
            threshold = float(p["amt_exclusion_phaseout_threshold_by_status"][status])
            income = pl.when(itemized > standard).then(taxinc + property_tax).otherwise(taxinc)
            exclusion = pl.when(income > threshold).then(
                (floor - p["amt_exclusion_phaseout_rate"] * (income - threshold)).clip(0, None)
            ).otherwise(floor)
            return (rate * (income - exclusion) - base_tax).clip(0, None)

        if p.in_effect("amt_rate"):
            status = pl.col("filing_status")
            whole_status = pl.when(status == "married_separate").then(0).when(status == "married_joint").then(1).when(
                status == "head_of_household").then(2).otherwise(3)
            whole_amt = pl.lit(0.0)
            for index, name in enumerate(("married_separate", "married_joint", "head_of_household", "single")):
                whole_amt = pl.when(whole_status == index).then(
                    amt_ia(pl.col("ia_xitded"), pl.col("ia_stded"), pl.col("ia_taxinc"), pl.col("proptax"), whole_tax, name)
                ).otherwise(whole_amt)
            split_h = agiw_positive
            property_h = pl.col("proptax") * agi_h / agi.clip(1e-9, None)
            amt_h = amt_ia(
                pl.when(split_h).then(xitdh).otherwise(pl.col("ia_xitded")),
                pl.when(split_h).then(stded_h_general).otherwise(pl.col("ia_stded")),
                pl.col("ia_taxinh"), property_h, tax_h, "married_separate",
            )
            amt_w = amt_ia(
                pl.when(split_h).then(xitdw).otherwise(0.0), pl.when(split_h).then(stded_h_general).otherwise(0.0),
                pl.col("ia_taxinw"), pl.col("proptax") - property_h, tax_w, "married_separate",
            )
            amt_j = amt_ia(pl.col("ia_xitded"), pl.col("ia_stded"), pl.col("ia_taxinc"), pl.col("proptax"), joint_tax, "married_joint")
            mfc_tax = pl.min_horizontal(joint_tax + amt_j, tax_h + amt_h + tax_w + amt_w)
            other_tax = whole_tax + whole_amt
        else:
            mfc_tax = pl.min_horizontal(joint_tax, tax_h + tax_w)
            other_tax = whole_tax
        df = df.with_columns(ia_statax=pl.when(is_mfc).then(mfc_tax).otherwise(other_tax))
        if p.in_effect("amt_rate"):
            df = df.with_columns(ia_stath=tax_h + amt_h, ia_statw=tax_w + amt_w)
        else:
            df = df.with_columns(ia_stath=tax_h, ia_statw=tax_w)

    # --- Personal Exemption Credit ---
    xmp = p.num("personal_exemption_credit")
    is_hoh = files_head_of_household()
    # Through 1997 TAXSIM credits no dependents and adds the head-of-household amount twice.
    statutory_credits = effective_year >= 1998 or behavior.credit_iowa_dependents_before_1998
    dependents = pl.col("depx") if statutory_credits else pl.lit(0.0)
    hoh_repeat = 0.0 if statutory_credits else xmp
    if p.in_effect("personal_credit_taxpayer_addition"):
        extra = p.num("personal_credit_taxpayer_addition")
        gcred = (xmp + extra) * (pl.col("ia_taxpayers") + aged_count()) + xmp * dependents
        gcred = pl.when(is_hoh).then(gcred + xmp + extra + hoh_repeat).otherwise(gcred)
    elif effective_year <= 1997:
        gcred = (xmp / 2.0) * (pl.col("ia_taxpayers") + aged_count()) + xmp * dependents
        gcred = pl.when(is_hoh).then(gcred + xmp / 2.0 + hoh_repeat).otherwise(gcred)
    else:
        gcred = xmp * (pl.col("depx") + pl.col("ia_taxpayers")) + (xmp / 2.0) * aged_count()
        gcred = pl.when(is_hoh).then(gcred + xmp).otherwise(gcred)
    if effective_year >= 2019 and not behavior.credit_iowa_dependents_in_full_on_separate_spouse_returns_per_statute and effective_year >= 1998:
        # When the separate-spouse tax is the lower, TAXSIM limits each spouse's personal credit to their own tax and
        # hands the dependents' credits out alternately (the taxpayer first), each limited to the higher spouse's tax
        # left after the personal credit (it passes that figure for both spouses).
        old_h = pl.col("page") >= 65
        old_w = pl.when(pl.col("sage") == 0).then(40).otherwise(pl.col("sage")) >= 65
        credit_h = xmp + (xmp / 2.0) * old_h.cast(pl.Float64)
        credit_w = xmp + (xmp / 2.0) * old_w.cast(pl.Float64)
        left = (pl.col("ia_stath") - credit_h).clip(0, None)
        dependents_h = pl.min_horizontal(xmp * ((pl.col("depx") + 1) // 2).cast(pl.Float64), left)
        dependents_w = pl.min_horizontal(xmp * (pl.col("depx") // 2).cast(pl.Float64), left)
        separate = pl.min_horizontal(pl.col("ia_statax"), credit_h + credit_w + dependents_h + dependents_w)
        gcred = pl.when(pl.col("ia_sepcmb")).then(separate).otherwise(gcred)
    df = df.with_columns(ia_gcred=gcred)
    df = df.with_columns(ia_statax=(pl.col("ia_statax") - pl.col("ia_gcred")).clip(0, None))

    # --- AMT --- (from 2021 it is part of the alternate tax step above)
    if effective_year < 2021 and (p.in_effect("amt_share_of_federal") or p.in_effect("amt_rate")):
        credits_first = behavior.apply_iowa_personal_credits_before_amt_per_statute
        if not credits_first:
            # TAXSIM works out the AMT on the tax before the personal credits and takes the credits off the total.
            df = df.with_columns(ia_statax=pl.col("ia_statax") + pl.col("ia_gcred"))
        if p.in_effect("amt_share_of_federal"):
            alty = pl.col("amt") * p.num("amt_share_of_federal")
        else:
            # Preferences: property tax only.
            addprf = pl.col("proptax")
            alminy = pl.col("ia_taxinc") + addprf
            if 1991 <= effective_year <= 2017:
                alminy = pl.when(over_thr).then(
                    alminy - pl.col("state_sales_or_income_tax_ded") * pl.col("itemized_deduction") / salt_capped_plus_mortgage.clip(1e-9, None)
                ).otherwise(alminy)
            exclnt_base = by_filing_status(p["amt_exclusion_base_by_status"])
            exclnt_thr = by_filing_status(p["amt_exclusion_phaseout_threshold_by_status"])
            exclnt = pl.when(alminy > exclnt_thr).then((exclnt_base - p["amt_exclusion_phaseout_rate"] * (alminy - exclnt_thr)).clip(0, None)).otherwise(exclnt_base)
            amt_rate_val = p.num("amt_rate")
            alty = (amt_rate_val * (alminy - exclnt) - pl.col("ia_statax")).clip(0, None)
        exy_single = p.num("no_tax_income_limit", "single")
        aged = aged_count() > 0
        aged_limit = p["amt_aged_exempt_income"]
        is_single = files_single()
        low_income_amt_exempt = (
            (is_single & ~aged & (pl.col("ia_agi") <= exy_single))
            | (is_single & aged & (pl.col("ia_agi") <= aged_limit["single"]))
            | (not_single & ~aged & (pl.col("ia_agi") <= exy_other))
            | (not_single & aged & (pl.col("ia_agi") <= aged_limit["other"]))
        )
        alty = pl.when(low_income_amt_exempt).then(0.0).otherwise(alty)
        df = df.with_columns(ia_statax=pl.col("ia_statax") + alty)
        if not credits_first:
            df = df.with_columns(ia_statax=(pl.col("ia_statax") - pl.col("ia_gcred")).clip(0, None))

    # --- Child/Dependent Care Credit ---
    posagi = pl.col("ia_agi").clip(0, None)
    # Federal credit before its liability limit, read undeflated; TAXSIM
    # leaves it at 0 before 1987.
    ccc_base = pl.col("ccc_uncapped") / flate
    if effective_year <= 1986 and behavior.read_federal_child_care_credit_before_1987:
        ccc_base = pl.col("federal_chcr")
    if p.in_effect("child_care_credit_expense_rate"):
        chcr = pl.col("childcare") * p.num("child_care_credit_expense_rate")
    else:
        share = p.value("child_care_credit_federal_share")
        if not isinstance(share, list):
            chcr = ccc_base * float(share)
        elif effective_year <= 1992:
            chcr = ccc_base * interpolate_table(pl.col("agi"), share)
        else:
            chcr = ccc_base * interpolate_table(posagi, share)
    df = df.with_columns(ia_chcr=chcr)

    # --- EITC ---
    earncr = pl.lit(0.0)
    if effective_year >= 1990:
        rate_eitc = p.num("eitc_rate")
        cap_eitc = p.num("eitc_agi_cap")
        # Tested against federal AGI (after the deduction for half the self-employment tax).
        earncr = pl.when(pl.col("agi") < cap_eitc).then(rate_eitc * pl.col("eitc")).otherwise(0.0)

        if p.in_effect("eitc_joint_worksheet"):
            nkid = pl.col("depx")
            e = p.value("eitc_joint_worksheet")
            start, maximum, rate = e["phaseout_start"], e["maximum"], e["phaseout_rate"]
            xlin2 = (
                pl.when(nkid == 0).then(float(start["none"]))
                .when((nkid >= 1) & (nkid <= 2)).then(float(start["one_or_two"]))
                .otherwise(float(start["more"]))
            )
            xlin3 = (pl.col("earned_income") - xlin2).clip(0, None)
            xlin5 = (
                pl.when(nkid == 0).then((maximum["none"] - xlin3 * rate["none"]).clip(0, None))
                .when(nkid == 1).then((maximum["one"] - xlin3 * rate["one"]).clip(0, None))
                .otherwise((maximum["more"] - xlin3 * rate["more"]).clip(0, None))
            )
            earncr = pl.when(is_joint & (earncr > 0)).then(e["share"] * xlin5).otherwise(earncr)

        caps_this_year = effective_year == p.num("eitc_eligibility_caps_year")
        if p.in_effect("eitc_eligibility_caps") and caps_this_year:
            caps = p.value("eitc_eligibility_caps")
            cap0, cap1_flat, cap2p_flat = float(caps["none"]), float(caps["one"]), float(caps["two_or_more"])
            over_0_flat = (pl.col("depx") == 0) & ((pl.col("earned_income") > cap0) | (pl.col("ia_agi") > cap0))
            over_1_flat = (pl.col("depx") == 1) & ((pl.col("earned_income") > cap1_flat) | (pl.col("ia_agi") > cap1_flat))
            over_2p_flat = (pl.col("depx") >= 2) & ((pl.col("earned_income") > cap2p_flat) | (pl.col("ia_agi") > cap2p_flat))
            over_flat = over_0_flat | over_1_flat | over_2p_flat
            if not behavior.apply_iowa_eitc_caps_as_in_2010_law:
                # TAXSIM caps only joint returns.
                over_flat = pl.lit(False)
            if p.in_effect("eitc_joint_eligibility_caps"):
                joint_caps = p.value("eitc_joint_eligibility_caps")

                def over(cap_key: str, kids: pl.Expr) -> pl.Expr:
                    cap = float(joint_caps[cap_key])
                    return kids & ((pl.col("earned_income") > cap) | (pl.col("ia_agi") > cap))

                if behavior.apply_iowa_eitc_caps_as_in_2010_law:
                    over_joint = (
                        over("none", pl.col("depx") == 0)
                        | over("one", pl.col("depx") == 1)
                        | over("two_or_more", pl.col("depx") >= 2)
                    )
                else:
                    # TAXSIM tests one child against the no-child cap and two
                    # children against the one-child cap.
                    over_joint = over("none", pl.col("depx") == 1) | over("one", pl.col("depx") == 2)
                in_joint_branch = is_joint & (earncr > 0)
                earncr = pl.when(in_joint_branch & over_joint).then(0.0).otherwise(earncr)
                earncr = pl.when(~in_joint_branch & over_flat).then(0.0).otherwise(earncr)
            else:
                earncr = pl.when(over_flat).then(0.0).otherwise(earncr)
    df = df.with_columns(ia_earncr=earncr)

    if effective_year <= 1989:
        df = df.with_columns(ia_statax=(pl.col("ia_statax") - pl.col("ia_chcr") - pl.col("ia_earncr")).clip(0, None))
    if 1990 <= effective_year <= 2006:
        df = df.with_columns(
            ia_statax=(pl.col("ia_statax") - pl.col("ia_earncr")).clip(0, None) - pl.col("ia_chcr")
        )
    exy_single = p.num("no_tax_income_limit", "single")
    is_single = files_single()
    # TAXSIM applies the single-filer worksheet from 2017 only.
    if effective_year >= 2017 or behavior.reduce_iowa_single_tax_before_2017:
        # The worksheet's income adds back excluded pensions and the Social Security Iowa does not tax; from 2017
        # the floor is the aged one for a taxpayer 65 or older.
        reported_benefits = 0.5 * pl.min_horizontal(
            pl.col("gssi"), (pl.col("agi") - pl.col("taxable_social_security") - 25_000).clip(0, None)
        )
        modified_income = pl.col("ia_agi")
        floor = pl.lit(exy_single)
        if effective_year >= 2017:
            modified_income = modified_income + pl.col("ia_penexc") + pl.when(pl.col("gssi") > 0).then(reported_benefits).otherwise(0.0)
            floor = pl.when(pl.col("page") >= 65).then(float(p["amt_aged_exempt_income"]["single"])).otherwise(floor)
        df = df.with_columns(
            ia_statax=pl.when(is_single).then(
                pl.max_horizontal(pl.min_horizontal(modified_income - floor, pl.col("ia_statax")), 0.0)
            ).otherwise(pl.col("ia_statax"))
        )
    if effective_year >= 2007:
        df = df.with_columns(ia_statax=pl.col("ia_statax") - pl.col("ia_earncr") - pl.col("ia_chcr"))

    if effective_year >= 1992:
        exy_other = p.num("no_tax_income_limit", "other")
        low_income = pl.when(is_single).then(pl.col("agi") <= exy_single).otherwise(pl.col("agi") <= exy_other)
        if effective_year >= 2022:
            # Actual-law years: a return with a taxpayer 65 or older owes no tax
            # at or below $24,000 (single) or $32,000 (other).
            aged_limit = p["amt_aged_exempt_income"]
            low_income = low_income | (
                (aged_count() > 0)
                & pl.when(is_single).then(pl.col("agi") <= aged_limit["single"]).otherwise(pl.col("agi") <= aged_limit["other"])
            )
        df = df.with_columns(
            ia_statax=pl.when((pl.col("ia_statax") > 0) & low_income).then(0.0).otherwise(pl.col("ia_statax"))
        )

    if effective_year >= 2023 and not behavior.compute_iowa_tax_from_2023_per_statute:
        df = df.with_columns(ia_statax=_taxsim_tax_from_2023(p, flate))

    df = df.with_columns(siitax=pl.col("ia_statax") * flate)
    return with_state_detail(
        df,
        agi=pl.col("ia_agi"),
        standard_deduction=pl.col("ia_stded"),
        itemized_deductions=pl.col("ia_xitded"),
        taxable_income=pl.col("ia_taxinc"),
        child_care_credit=pl.col("ia_chcr"),
        eic=pl.col("ia_earncr"),
        credits=pl.col("ia_gcred") + pl.col("ia_chcr") + pl.col("ia_earncr"),
        rate=rate_expr,
    )


def _taxsim_tax_from_2023(p: YearParams, flate: float) -> pl.Expr:
    """TAXSIM's Iowa tax from 2023 (`iatax23`): federal taxable income less pensions and taxable Social Security
    benefits, taxed by status, the exemption credit, the alternate tax and the refundable credits.
    """
    aged_pension_exclusion = (pl.col("page") >= 55) | (pl.col("sage") >= 55) | (aged_count() == 1)
    pended = pl.when(aged_pension_exclusion).then(pl.col("pensions")).otherwise(0.0)
    taxinc = (pl.col("taxable_income") - pended - pl.col("taxable_social_security")).clip(0, None)
    schedules = p.value("brackets_by_status")
    regtax = pl.when(files_joint()).then(bracket_tax(taxinc, schedules["joint"])).otherwise(bracket_tax(taxinc, schedules["other"]))
    deduction = pl.max_horizontal(pl.col("itemized_deduction"), pl.col("standard_deduction"))
    income_for_alternate = taxinc + deduction + pl.col("qbi_deduction") + pl.col("senior_deduction")
    aged = aged_count() >= 1
    floors = p.value("taxsim_alternate_floor")
    combined_floor = pl.when(aged).then(32000.0).otherwise(13500.0)
    single_floor = pl.when(aged).then(float(floors["aged"])).otherwise(float(floors["general"]))
    uses_combined = files_joint() | files_head_of_household()
    altax = pl.when(uses_combined).then(
        p.num("alternate_tax_rate") * (income_for_alternate - combined_floor).clip(0, None)
    ).otherwise((income_for_alternate - single_floor).clip(0, None))
    taxbc = pl.min_horizontal(regtax - pl.col("ia_gcred"), altax)
    chcr = pl.col("ccc_uncapped") / flate * interpolate_table(taxinc, p.value("child_care_credit_federal_share"))
    return taxbc.clip(0, None) - chcr - pl.col("ia_earncr")
