"""Pennsylvania personal income tax calculator."""


from __future__ import annotations
import polars as pl

from taxsim_py.engine.inputs import aged_count, files_joint, taxpayer_count
from taxsim_py.engine.schema import PARAMETERS_ROOT, YearParams, load_yaml
from taxsim_py.engine.state import phaseout_steps, with_state_detail, dividend_input_adjustment, unemployment_total
from taxsim_py.behavior import BehaviorProfile, TAXSIM_BEHAVIOR
from taxsim_py.engine.state_extrapolation import deflate_for_extrapolation, resolve_state_year

PA_PARAMS = load_yaml(PARAMETERS_ROOT / "states" / "pa" / "income_tax.yaml")


def compute_pa_tax(df: pl.DataFrame, year: int, behavior: BehaviorProfile = TAXSIM_BEHAVIOR) -> pl.DataFrame:
    """Calculate Pennsylvania income tax for each row."""
    effective_year, flate = resolve_state_year(year, behavior, PA_PARAMS)
    y = effective_year
    p = YearParams(PA_PARAMS, effective_year)
    dividend_adjustment = dividend_input_adjustment()
    # Federal Schedule E income: other property income, plus S corporation
    # income from 1987.
    # Schedule E income (rents and S corporation income) is one class of income, and its net loss cannot offset the others.
    schede = (pl.lit(0.0) if year >= 2024 and not behavior.count_other_property_income_from_2024 else pl.col("otherprop")) + (
        pl.col("scorp") if year >= 1987 else 0.0
    )
    df = df.with_columns(pa_schede=schede.clip(0, None))
    df = deflate_for_extrapolation(df, flate, extra=("pa_schede",))

    # Positive income classes only; negative wages and capital losses do not
    # offset. Business income is not deflated in projected years. Pensions
    # are exempt from the retirement age.
    business = (
        pl.col("psemp") + pl.col("ssemp") + pl.col("pbusinc") + pl.col("pprofinc") + pl.col("sbusinc")
        + pl.col("sprofinc")
    )
    # TAXSIM gives a married couple's pensions to the spouse aged 55 or older (halves if both or neither are), and taxes
    # each share unless that spouse is 60 or older. Pennsylvania exempts retirement income from the plan's retirement age
    # (REV-636) with no fixed age, so TAXSIM's reading is kept in both modes.
    pensions = pl.col("pensions")
    head_55, spouse_55 = pl.col("page") >= 55, pl.col("sage") >= 55
    head_share = (
        pl.when(pl.col("mstat") != 2).then(pensions)
        .when(head_55 & ~spouse_55).then(pensions)
        .when(~head_55 & spouse_55).then(0.0)
        .otherwise(pensions / 2.0)
    )
    taxable_pensions = (
        pl.when(pl.col("page") < 60).then(head_share).otherwise(0.0)
        + pl.when(pl.col("sage") < 60).then(pensions - head_share).otherwise(0.0)
    )
    income = (
        pl.col("pwages").clip(0, None) + pl.col("swages").clip(0, None)
        + pl.col("dividends") + dividend_adjustment + pl.col("intrec")
        + business.clip(0, None)
        + (pl.col("stcg") + pl.col("ltcg")).clip(0, None)
        + pl.col("pa_schede")
        + taxable_pensions
    )
    if not behavior.count_nonproperty_income_once:
        # TAXSIM's variable for other non-property income (`d(23)`) is part of Pennsylvania income.
        income = income + pl.col("nonprop")
    taxinc = income.clip(0, None)
    statax = taxinc * p.num("rate")

    # --- Tax forgiveness ---
    is_joint = files_joint()
    taxpayers = taxpayer_count()
    nkid = pl.col("depx")
    if y <= 1994:
        # The spouse is counted as the first claimant after the filer.
        # A dependent filer (no taxpayer) counts no one.
        dep1 = pl.when(taxpayers < 1).then(0.0).when(is_joint | (nkid >= 1)).then(1.0).otherwise(0.0)
        dep2 = pl.when(taxpayers < 1).then(0.0).when(is_joint).then(nkid).otherwise((nkid - 1).clip(0, None))
    else:
        dep1 = taxpayers
        dep2 = nkid
    a = p.value("forgiveness_allowance")
    if y <= 1993:
        allow = a["base"] + dep1 * a["first"] + dep2 * a["other"]
    elif y == 1994:
        allow = pl.when(is_joint).then(a["joint_base"]).otherwise(a["base"]) + a["dependent"] * nkid
    elif y <= 1996:
        allow = a["base"] + (dep1 - 1 + dep2) * a["dependent"]
    elif y == 1998:
        single_allow = a["first"] * (dep1 + dep2.clip(None, 1)) + (dep2 - 1).clip(0, None) * a["other"]
        allow = pl.when(is_joint).then(a["first"] * dep1 + dep2 * a["other"]).otherwise(single_allow)
    else:
        allow = a["first"] * dep1 + a["other"] * dep2
    eligibility = taxinc
    if behavior.apply_pennsylvania_forgiveness_rules:
        # Schedule SP eligibility income adds nontaxable income such as
        # unemployment compensation and exempt pensions.
        eligibility = taxinc + unemployment_total() + pl.when(aged_count() > 0).then(pl.col("pensions")).otherwise(0.0)
    remain = (eligibility - allow).clip(0, None)
    forgiven_share = (1.0 - remain / p.num("forgiveness_phaseout")).clip(0, None)
    if p.in_effect("forgiveness_step"):
        step = p.value("forgiveness_step")
        forgiven_share = (1.0 - float(step["share"]) * phaseout_steps(remain / float(step["income"]), behavior)).clip(0, None)
    elif behavior.apply_pennsylvania_forgiveness_rules:
        # Forgiveness falls 10% for each tenth of the phaseout (or part).
        tenth = p.num("forgiveness_phaseout") / 10.0
        forgiven_share = (1.0 - 0.1 * phaseout_steps(remain / tenth, behavior)).clip(0, None)
    credit = statax * forgiven_share
    statax = statax - credit
    care_share = p.num("child_care_credit_share") if p.in_effect("child_care_credit_share") else 0.0
    if not behavior.pay_pennsylvania_child_care_credit_only_from_2023 and p.in_effect("taxsim_child_care_credit_share"):
        care_share = p.num("taxsim_child_care_credit_share")
    if care_share > 0:
        care_credit = care_share * (pl.col("ccc_uncapped") / flate).clip(0, None)
        if p.in_effect("child_care_credit_per_child_cap"):
            cap = p.value("child_care_credit_per_child_cap")
            per_child = pl.when(pl.col("agi") <= cap["income_limit"]).then(float(cap["low_income"])).otherwise(
                float(cap["high_income"])
            )
            care_credit = pl.min_horizontal(care_credit, per_child * pl.col("depx").clip(0, 2))
        statax = statax - care_credit
        credit = credit + care_credit
    if p.in_effect("eitc_federal_share"):
        eitc_credit = p.num("eitc_federal_share") * pl.col("eitc")
        statax = statax - eitc_credit
        credit = credit + eitc_credit

    df = df.with_columns(pa_taxinc=taxinc, siitax=statax * flate)
    return with_state_detail(
        df, agi=income, taxable_income=taxinc, credits=credit, rate=pl.lit(p.num("rate"))
    )
