"""Nebraska individual income tax calculator."""


from __future__ import annotations
import polars as pl

from taxsim_py.engine.brackets import bracket_rate, bracket_tax, scale_brackets
from taxsim_py.engine.inputs import aged_count, federal_exemption_count, files_joint, files_separate, files_single, taxpayer_count
from taxsim_py.engine.schema import PARAMETERS_ROOT, YearParams, load_yaml, resolve_year
from taxsim_py.engine.state import by_filing_status, checkpoint, federal_zero_bracket, with_state_detail
from taxsim_py.behavior import BehaviorProfile, TAXSIM_BEHAVIOR
from taxsim_py.engine.state_extrapolation import deflate_for_extrapolation, resolve_state_year

NE_PARAMS = load_yaml(PARAMETERS_ROOT / "states" / "ne" / "income_tax.yaml")
FEDERAL_INCOME_TAX_PARAMS = load_yaml(PARAMETERS_ROOT / "national" / "income_tax.yaml")



def _additional_tax(dagi: pl.Expr, bounds: list[float], rates: list[float]) -> tuple[pl.Expr, pl.Expr]:
    """High-income additional tax on federal AGI, and its amount at the top bound."""
    s1, s2, s3, s4 = bounds
    r2, r3, r4 = rates
    schedule = [[0.0, 0.0], [s1, r2], [s2, r3], [s3, r4]]
    capped = (s4 - s3) * r4 + (s3 - s2) * r3 + (s2 - s1) * r2
    return bracket_tax(dagi, schedule), pl.lit(capped)


def compute_ne_tax(df: pl.DataFrame, year: int, behavior: BehaviorProfile = TAXSIM_BEHAVIOR) -> pl.DataFrame:
    """Calculate Nebraska income tax for each row."""
    effective_year, flate = resolve_state_year(year, behavior, NE_PARAMS)
    y = effective_year
    p = YearParams(NE_PARAMS, effective_year)
    df = deflate_for_extrapolation(df, flate)

    status = pl.col("filing_status")
    is_single = files_single()
    is_joint = files_joint()
    is_sep = files_separate()
    sep = pl.when(is_sep).then(2.0).otherwise(1.0)
    txp = taxpayer_count()
    exemps = txp + pl.col("depx")
    fed_agi = pl.col("agi")
    ne_agi = fed_agi
    if y >= 2015:
        # Taxable Social Security is subtracted in full up to an AGI limit.
        limit = pl.when(is_joint).then(p.num("social_security_exclusion_agi_limit", "married_joint")).otherwise(
            p.num("social_security_exclusion_agi_limit", "single")
        )
        if p.in_effect("taxsim_social_security_exclusion_agi_limit_single") and not behavior.use_nebraska_published_social_security_limit_per_statute:
            limit = pl.when(is_joint).then(limit).otherwise(p.num("taxsim_social_security_exclusion_agi_limit_single"))
        above = p.num("social_security_exclusion_share_above_limit")
        ne_agi = ne_agi - pl.when(fed_agi <= limit).then(pl.col("taxable_social_security")).otherwise(
            above * pl.col("taxable_social_security")
        )
    salt_ded = pl.col("state_sales_or_income_tax_ded")
    itemizes = pl.col("itemizes")

    limit_inflation = p.num("itemized_limit_inflation")
    if y == 2017 and not behavior.use_nebraska_high_income_tables_per_statute:
        limit_inflation = float(p.num("taxsim_itemized_limit_inflation"))
    if y <= 2012:
        base = p.num("itemized_limit_threshold_base") * (p.num("itemized_limit_inflation") if y >= 1992 else 1.0)
        phas92 = base / sep
    elif y <= 2017:
        phas92 = (
            p.num("itemized_limit_threshold_base")
            * limit_inflation
            * by_filing_status(p["itemized_limit_status_multiplier"])
        )
    else:
        phas92 = None

    if y <= 1986:
        statax = p.num("federal_tax_share") * pl.col("pre1987_pretax").clip(0, None)
        if not behavior.tax_nebraska_before_1987_per_statute:
            # TAXSIM takes a share of a federal tax variable it never sets.
            statax = pl.lit(0.0)
        taxbc = pl.col("pre1987_taxbc")
        almtax = pl.col("pre1987_almtax")
        fed_ccc = pl.col("federal_chcr")
        ne_agi = pl.lit(0.0)
        xitded = pl.lit(0.0)
        stded = pl.lit(0.0)
        exemp = pl.lit(0.0)
        taxinc = pl.lit(0.0)
        rt = p.num("federal_tax_share") * pl.col("federal_source_rate") / 100.0
    else:
        taxbc = pl.col("regular_tax")
        almtax = pl.col("amt")
        fed_ccc = pl.col("federal_chcr")

        # --- Deductions ---
        fed_itemized = pl.when(itemizes).then(pl.col("itemized_deduction")).otherwise(0.0)
        fed_std = pl.when(itemizes).then(0.0).otherwise(pl.col("standard_deduction"))
        if not behavior.zero_nebraska_standard_deduction_when_federal_itemizes:
            # TAXSIM keeps the federal standard deduction (zero only on its forced-itemizing pass).
            fed_std = federal_zero_bracket()
        if y <= 2017:
            xitded = (fed_itemized - salt_ded).abs() * itemizes.cast(pl.Float64)
            stded = fed_std
        else:
            stit = pl.min_horizontal(p.num("salt_cap") / sep, salt_ded)
            xitded = (fed_itemized - stit).abs() * itemizes.cast(pl.Float64)
            if not behavior.limit_nebraska_property_tax_deduction_to_federal_cap:
                # TAXSIM removes the capped state and property tax, then adds the property tax back.
                cap = p.num("salt_cap") / sep
                xitded = (
                    (fed_itemized - pl.min_horizontal(cap, salt_ded + pl.col("proptax"))).clip(0, None)
                    + pl.min_horizontal(cap, pl.col("proptax"))
                ) * itemizes.cast(pl.Float64)
            std = p["standard_deduction"]
            aged_add = p["standard_deduction_aged_addition"]
            stded = by_filing_status({
                "single": resolve_year(std["single"], y),
                "married_joint": resolve_year(std["married"], y),
                "married_separate": resolve_year(std["married"], y),
                "head_of_household": resolve_year(std["head_of_household"], y),
            }) / sep + by_filing_status({
                "single": resolve_year(aged_add["single"], y),
                "married_joint": resolve_year(aged_add["married"], y),
                "married_separate": resolve_year(aged_add["married"], y),
                "head_of_household": resolve_year(aged_add["head_of_household"], y),
            }) * aged_count()
        if p.in_effect("standard_deduction_phaseout_rate"):
            reduction = p.num("standard_deduction_phaseout_rate") * (fed_agi - phas92).clip(0, None)
            stded = (fed_std - reduction).clip(0, None)
            if p.in_effect("standard_deduction_override_married"):
                married_value = (p.num("standard_deduction_override_married") / sep - reduction).clip(0, None)
                stded = pl.when(is_joint | is_sep).then(married_value).otherwise(stded)
            if p.in_effect("standard_deduction_override_single"):
                stded = pl.when(is_single).then((p.num("standard_deduction_override_single") - reduction).clip(0, None)).otherwise(stded)
        if p.in_effect("standard_deduction_property_tax_cap"):
            cap = p.num("standard_deduction_property_tax_cap")
            stded = pl.when(pl.col("proptax") > 0).then(
                fed_std - pl.min_horizontal(pl.col("proptax"), cap * txp)
            ).otherwise(stded)
        if y == 1987:
            deduc = (fed_itemized - salt_ded - stded).clip(0, None)
        else:
            deduc = pl.max_horizontal(xitded, stded)
        exemp = federal_exemption_count(y) * p.num("exemption") if y <= 1992 else pl.lit(0.0)
        df, (taxinc,) = checkpoint(df, ne_taxinc=(ne_agi - exemp - deduc).clip(0, None))

        # --- Tax ---
        if y <= 1992:
            tables = p.value("brackets")
            income = taxinc
            if p.in_effect("zero_bracket"):
                income = (taxinc - by_filing_status(p.value("zero_bracket"))).clip(0, None)
            statax = pl.lit(0.0)
            for status_name, brackets in tables.items():
                statax = pl.when(status == status_name).then(bracket_tax(income, brackets)).otherwise(statax)
            rt = pl.lit(0.0)
            for status_name, brackets in tables.items():
                rt = pl.when(status == status_name).then(bracket_rate(income, brackets)).otherwise(rt)
        else:
            factor = p.num("bracket_inflation")
            source = p.value("brackets")
            if p.in_effect("taxsim_brackets") and not behavior.use_nebraska_high_income_tables_per_statute:
                source = p.value("taxsim_brackets")
                if p.in_effect("taxsim_bracket_inflation"):
                    factor = p.num("taxsim_bracket_inflation")
            tables = {status_name: scale_brackets(values, factor) for status_name, values in source.items()}
            taxy = pl.when(is_sep).then(2.0 * taxinc).otherwise(taxinc)
            dagi = pl.when(is_sep).then(2.0 * fed_agi).otherwise(fed_agi)
            table_of = {"single": "single", "married_joint": "married_joint",
                        "married_separate": "married_joint", "head_of_household": "head_of_household"}
            statax = pl.lit(0.0)
            rt = pl.lit(0.0)
            for status_name, table_name in table_of.items():
                brackets = tables[table_name]
                statax = pl.when(status == status_name).then(bracket_tax(taxy, brackets) / sep).otherwise(statax)
                rt = pl.when(status == status_name).then(bracket_rate(taxy, brackets)).otherwise(rt)
            df, (statax, rt) = checkpoint(df, ne_table_tax=statax, ne_rt=rt)
            if p.in_effect("additional_tax_rates"):
                bound_factor = limit_inflation if y >= 2013 else 1.0
                rates = p.value("additional_tax_rates")
                surtax = pl.lit(0.0)
                cap_amount = pl.lit(0.0)
                top = pl.lit(0.0)
                for status_name, table_name in table_of.items():
                    bounds = [float(b) * bound_factor for b in p.value("additional_tax_bounds", table_name)]
                    if not behavior.use_nebraska_high_income_tables_per_statute:
                        typos = NE_PARAMS["taxsim_additional_tax_bounds"].get(y, {})
                        if table_name in typos:
                            bounds = [float(b) for b in typos[table_name]]
                    amount, capped = _additional_tax(dagi, bounds, rates)
                    surtax = pl.when(status == status_name).then(amount).otherwise(surtax)
                    cap_amount = pl.when(status == status_name).then(capped).otherwise(cap_amount)
                    top = pl.when(status == status_name).then(pl.lit(bounds[3])).otherwise(top)
                limited = pl.when(dagi <= top).then(surtax).otherwise(cap_amount)
                # TAXSIM adds single filers' additional tax twice.
                single_added = limited if behavior.add_nebraska_single_additional_tax_once else surtax + limited
                added = pl.when(is_single).then(single_added).otherwise(limited / sep)
                high = dagi > phas92
                big = taxinc >= p.num("additional_tax_min_taxable_income")
                statax = (
                    pl.when(high & big)
                    .then(statax + added)
                    .when(high & (taxinc < p["additional_tax_agi_share"] * (fed_agi - phas92)))
                    .then(rt * taxinc)
                    .otherwise(statax)
                )

    # --- Credits ---
    cred = p.num("personal_credit")
    if y <= 1992:
        stxcr = cred * exemps
    else:
        if p.in_effect("personal_credit_phaseout_threshold"):
            threshold = by_filing_status(p.value("personal_credit_phaseout_threshold"))
            agdiff = (fed_agi - threshold).clip(0, None)
            xcred = (
                cred - p.num("personal_credit_phaseout_amount") * agdiff / (p.num("personal_credit_phaseout_step") / sep)
            ).clip(0, None)
        else:
            xcred = pl.lit(cred).clip(0, None)
        # The federal exemption count is deflated with the other federal
        # values when a later year is projected.
        stxcr = xcred * federal_exemption_count(y) / flate
        if y >= 2024 and behavior.mode.value != "statutory":
            # TAXSIM's 2024 on routine counts taxpayers and dependents directly, not the deflated federal count.
            stxcr = xcred * (taxpayer_count() + pl.col("depx"))
    credit = stxcr
    if y >= 1987:
        credit = credit + p.num("elderly_credit_share") * pl.col("federal_elder")
    chcr = p.num("child_care_credit_share") * fed_ccc
    chcref = pl.lit(0.0)
    refundable_zone = pl.lit(False)
    if p.in_effect("child_care_refundable"):
        ref = p.value("child_care_refundable")
        refundable_zone = fed_agi <= float(ref["agi_limit"])
        share = 1.0 - ref["share_step"] * (fed_agi - float(ref["full_share_agi"])).clip(0, None)
        chcref = pl.when(refundable_zone).then(share * fed_ccc).otherwise(0.0)
        if not behavior.pay_nebraska_refundable_child_care_per_statute and y <= 2023:
            # TAXSIM takes a share of the federal credit before its liability limit.
            fagi = fed_agi - 0.002
            credit_before_limit = pl.col("ccc_uncapped") / flate
            if y <= 2020:
                share = (1 - 0.01 * (fagi - 22_000) / 1000).clip(0, 1)
                chcref = pl.when(refundable_zone).then(share * credit_before_limit).otherwise(0.0)
            elif y == 2021:
                earned_primary = pl.col("pwages") + pl.col("psemp") + pl.col("pbusinc") + pl.col("pprofinc")
                earned_spouse = pl.col("swages") + pl.col("ssemp") + pl.col("sbusinc") + pl.col("sprofinc")
                earnmin = pl.when(is_joint).then(pl.min_horizontal(earned_primary, earned_spouse)).otherwise(earned_primary)
                x6 = pl.min_horizontal(pl.col("childcare"), earnmin.clip(0, None), 8000.0 * pl.col("dep13").clip(None, 2))
                x9 = (1 - 0.1 * (fagi - 22_000) / 1000).clip(0, 1)
                chcref = pl.when(fagi <= 29_000).then(x6 * 0.5 * x9).otherwise(0.0)
            elif y == 2022 or y == 2023:
                share = (1 - 0.1 * (fagi - 22_000) / 1000).clip(0, 1)
                chcref = pl.when(fagi < 29_000).then(share * credit_before_limit).otherwise(0.0)
    if p.in_effect("child_care_refundable") and not behavior.pay_nebraska_refundable_child_care_per_statute and y >= 2024:
        fagi = fed_agi - 0.002
        # 2024 on: the share of expenses (up to $6,000, $3,000 a child, earnings) falls from 35% and from 100%
        # with income, continuously.
        earned_primary = pl.col("pwages") + pl.col("psemp") + pl.col("pbusinc") + pl.col("pprofinc")
        earned_spouse = pl.col("swages") + pl.col("ssemp") + pl.col("sbusinc") + pl.col("sprofinc")
        earnmin = pl.when(is_joint).then(pl.min_horizontal(earned_primary, earned_spouse)).otherwise(earned_primary)
        care = pl.min_horizontal(pl.lit(6000.0), pl.col("childcare"), 3000.0 * pl.col("dep13").clip(None, 2), earnmin.clip(0, None))
        frac1 = pl.max_horizontal(pl.lit(28.0), 35.0 - (fagi - 15_000).clip(0, None) / 2000.0) / 100.0
        frac2 = pl.max_horizontal(pl.lit(30.0), 100.0 - 10.0 * (fagi - 22_000).clip(0, None) / 1000.0) / 100.0
        chcref = pl.when(fagi <= 29_000).then(frac1 * frac2 * care).otherwise(0.0)
    credit = credit + pl.when(refundable_zone).then(0.0).otherwise(chcr)
    df, (statax,) = checkpoint(df, ne_tax_before_credits=statax)
    statax = statax + p.num("minimum_tax_share") * almtax
    statax = (statax - credit).clip(0, None)
    statax = pl.min_horizontal(taxbc + almtax, statax)
    earncr = p.num("eitc_match_rate") * pl.col("eitc")
    ctc = pl.lit(0.0)
    if p.in_effect("child_tax_credit"):
        # Any income when child care expenses are paid, otherwise income at or
        # below the federal poverty guideline.
        c = p.value("child_tax_credit")
        household = taxpayer_count() + pl.col("depx")
        poverty = float(c["poverty_first_person"]) + float(c["poverty_additional_person"]) * (household - 1)
        eligible = (pl.col("childcare") > 0) | (pl.col("agi") <= poverty)
        amount = bracket_rate(pl.col("agi"), c["amount"])
        ctc = pl.when(eligible).then(amount * pl.col("dep6")).otherwise(0.0)
        if not behavior.pay_nebraska_child_tax_credit_per_statute:
            # TAXSIM works the credit out and then overwrites it with the child care credit in the same variable.
            ctc = pl.lit(0.0)
    statax = statax - chcref - earncr - ctc
    final_chcr = pl.when(chcref > 0).then(chcref).otherwise(chcr)
    final_credit = credit + chcref + earncr + ctc

    return with_state_detail(
        df.with_columns(siitax=statax * flate),
        agi=ne_agi,
        exemptions=exemp,
        standard_deduction=stded,
        itemized_deductions=xitded,
        taxable_income=taxinc,
        child_care_credit=final_chcr,
        eic=earncr,
        credits=final_credit,
        rate=rt,
    )
