"""Massachusetts individual income tax calculator."""


from __future__ import annotations
import polars as pl

from taxsim_py.engine.inputs import aged_count, files_head_of_household, files_joint, files_separate, files_single, taxpayer_count
from taxsim_py.engine.schema import PARAMETERS_ROOT, YearParams, load_yaml
from taxsim_py.engine.state import unemployment_total, with_state_detail
from taxsim_py.behavior import BehaviorProfile, TAXSIM_BEHAVIOR
from taxsim_py.engine.state_extrapolation import deflate_for_extrapolation, resolve_state_year

MA_PARAMS = load_yaml(PARAMETERS_ROOT / "states" / "ma" / "income_tax.yaml")


def compute_ma_tax(df: pl.DataFrame, year: int, behavior: BehaviorProfile = TAXSIM_BEHAVIOR) -> pl.DataFrame:
    effective_year, flate = resolve_state_year(year, behavior, MA_PARAMS)
    y = effective_year
    p = YearParams(MA_PARAMS, effective_year)

    df = df.with_columns(ma_untax=pl.col("taxable_unemployment"))
    # Payroll figures come from the federal run and are never deflated.
    own_fica = pl.col("own_fica_primary")
    own_fica_spouse = pl.lit(0.0)
    if behavior.deduct_massachusetts_employee_payroll_tax_per_spouse:
        # MA-001: only the employee half of wage payroll tax, for each spouse
        # up to the cap; TAXSIM credits both halves and only the primary
        # earner's.
        own_fica = own_fica - 0.5 * pl.col("own_wage_fica_primary")
        own_fica_spouse = pl.col("own_fica_secondary") - 0.5 * pl.col("own_wage_fica_secondary")
    if flate != 1.0 and not behavior.deflate_massachusetts_payroll_tax_deduction_per_statute:
        # In a projected year TAXSIM hands the state its payroll tax in deflated dollars.
        own_fica, own_fica_spouse = own_fica / flate, own_fica_spouse / flate
    df = df.with_columns(ma_c183=own_fica, ma_c183_spouse=own_fica_spouse, ma_setax=pl.col("payroll_setax"))
    # Federal Schedule E income: other property income, plus S corporation
    # income from 1987.
    other_property = pl.col("otherprop")
    if y >= 2022 and not behavior.count_other_property_income_from_2024:
        # TAXSIM's 2024 on routine leaves other property income out of Massachusetts income.
        other_property = pl.lit(0.0)
    df = df.with_columns(ma_schede=other_property)

    df = deflate_for_extrapolation(df, flate, extra=("ma_untax", "ma_schede"))
    # S corporation income is not deflated in projected years.
    if y >= 1987:
        df = df.with_columns(ma_schede=pl.col("ma_schede") + pl.col("scorp"))

    is_joint = files_joint()
    is_hoh = files_head_of_household()
    is_sep = files_separate()
    is_single = files_single()
    not_sep = ~is_sep
    n_tp = taxpayer_count()
    if y <= 1984:
        x_flag = pl.when(is_joint).then(1.0).otherwise(0.0)
    elif behavior.exclude_separate_returns_from_massachusetts_exemption_carryover:
        x_flag = pl.when(is_sep).then(0.0).otherwise(1.0)
    else:
        # TAXSIM's test `mst.ne.3.or.mst.ne.6` is true for every status.
        x_flag = pl.lit(1.0)

    # Negative wages count as self-employment income.
    w1 = pl.col("pwages").clip(0, None)
    w2 = pl.col("swages").clip(0, None)
    wages = w1 + w2
    semp = pl.col("psemp") + pl.col("ssemp") + pl.col("pwages").clip(None, 0) + pl.col("swages").clip(None, 0)
    # Business income is not deflated in projected years.
    business_h = pl.col("pbusinc") + pl.col("pprofinc")
    business_w = pl.col("sbusinc") + pl.col("sprofinc")
    d17 = semp + business_h + business_w
    if y < 2022 and not behavior.count_business_and_professional_inputs_as_income:
        # TAXSIM's net business income (`d(17)`) is self-employment only until 2024.
        d17 = semp
    ui_total = unemployment_total()
    interest_exclusion = p.num("interest_exclusion_per_taxpayer")
    if p.in_effect("taxsim_interest_exclusion_per_taxpayer") and not behavior.exclude_massachusetts_bank_interest_from_2024_per_statute:
        # TAXSIM's 2024 on routine drops the bank interest exclusion.
        interest_exclusion = p.num("taxsim_interest_exclusion_per_taxpayer")

    # --- Exemptions ---
    xmps = p.num("personal_exemption")
    xmplim = p.num("married_exemption_cap")
    if y <= 1986:
        spy = pl.min_horizontal(w1, w2)
        txp_joint = pl.min_horizontal(xmps + spy + p.num("married_additional_exemption_base"), pl.lit(xmplim))
    else:
        txp_joint = pl.lit(min(2.0 * xmps, xmplim))
    txp = pl.when(is_joint).then(txp_joint).otherwise(xmps)
    if y >= 1994:
        txp = pl.when(is_hoh).then(p.num("head_of_household_exemption")).otherwise(txp)
    ageex = aged_count() * p.num("aged_exemption")
    depex = pl.col("depx") * p.num("dependent_exemption")
    exemp = depex + ageex + txp

    # --- Part B income ---
    b1inc = wages + d17
    b2inc = pl.col("pensions")
    untax = pl.col("ma_untax")
    if 1982 <= y <= 1989:
        b2inc = b2inc + untax
    if y <= 1989:
        b1inc = b1inc + pl.col("ma_schede")
        binc = b1inc + b2inc
    else:
        binc = b1inc + b2inc + pl.col("ma_schede") + untax
        if y == 2009:
            binc = binc - untax + ui_total
        if p.in_effect("ui_exclusion_cap_per_person"):
            nsize = pl.when(is_joint).then(2.0).otherwise(1.0) + pl.col("depx").floor()
            ulevel = 2.0 * p.num("ui_exclusion_poverty_level") * nsize
            hyun = pl.col("agi") + pl.col("gssi") - pl.col("taxable_social_security") + ui_total - untax
            cap = p.num("ui_exclusion_cap_per_person")
            unded = pl.when(hyun <= ulevel).then(
                pl.min_horizontal(ui_total - pl.col("sui"), pl.lit(cap)) + pl.min_horizontal(pl.col("sui"), pl.lit(cap))
            ).otherwise(0.0)
            binc = pl.when(ui_total > 0).then(binc + ui_total - untax - unded).otherwise(binc)
        if y >= 1999:
            binc = binc + (pl.col("intrec") - interest_exclusion * n_tp).clip(0, None)

    # --- Part B deductions ---
    # Each spouse's employee payroll tax, up to the cap.
    fica_cap = pl.lit(float(p["payroll_tax_deduction_cap"]))
    fica = (
        pl.min_horizontal(pl.col("ma_c183"), fica_cap)
        + pl.min_horizontal(pl.col("ma_c183_spouse"), fica_cap)
    )
    setax = pl.col("ma_setax")

    ndep13 = pl.col("dep13").clip(None, 2.0).floor()
    d209 = pl.col("depx") - pl.col("dep18")
    ndep = (d209 + ndep13).clip(None, 2.0).floor()
    dependent_deduction = p.value("dependent_deduction")
    if "flat" in dependent_deduction:
        ch = pl.lit(float(dependent_deduction["flat"]))
    else:
        ch = dependent_deduction["per_child"] * ndep13
    if p.in_effect("dependent_deduction_cap_per_child"):
        ch = pl.min_horizontal(ch, p.num("dependent_deduction_cap_per_child") * pl.col("dep13"))
    ch = pl.when(is_sep).then(0.0).otherwise(ch)
    ch1 = pl.lit(0.0)
    chcred = pl.lit(0.0)
    child_care_deduction = p.in_effect("child_care_deduction_per_child")
    if 2011 <= y <= 2020 and not behavior.allow_massachusetts_child_care_deduction_2011_2020:
        # TAXSIM's test `law.eq.2010.and.law.le.2020` keeps it in 2010 only.
        child_care_deduction = False
    if child_care_deduction:
        ch1 = pl.min_horizontal(pl.col("childcare"), p.num("child_care_deduction_per_child") * ndep13)
    elif p.in_effect("child_care_credit_per_child"):
        chcred = pl.min_horizontal(pl.col("childcare"), p.num("child_care_credit_per_child") * ndep13)
    earned = pl.col("earned_income")
    # A joint return splits earnings by spouse, with self-employment tax
    # shared by business income.
    setaxh = setax * business_h / d17
    setaxw = setax * business_w / d17
    earnww_se = (semp - 0.5 * (setax - setaxh - setaxw)).clip(0, None)
    earnh = pl.when(d17 > 0).then(
        (w1 + business_h - 0.5 * setaxh).clip(0, None) + earnww_se / 2
    ).otherwise(w1 + (earned - w1 - w2).clip(0, None) / 2)
    earnw = pl.when(d17 > 0).then(
        (w2 + business_w - 0.5 * setaxw).clip(0, None) + earnww_se / 2
    ).otherwise(w2 + (earned - w1 - w2).clip(0, None) / 2)
    ch1 = pl.when(is_joint).then(pl.min_horizontal(ch1, earnh, earnw)).otherwise(pl.min_horizontal(ch1, earned)).clip(0, None)
    chcred = pl.when(is_joint).then(pl.min_horizontal(chcred, earnh, earnw)).otherwise(pl.min_horizontal(chcred, earned)).clip(0, None)
    ch = pl.max_horizontal(ch, ch1)
    has_dep = ndep > 0
    ch = pl.when(has_dep).then(ch).otherwise(0.0)
    chcred = pl.when(has_dep).then(chcred).otherwise(0.0)

    rnt = pl.lit(0.0)
    if p.in_effect("rent_deduction_share"):
        rnt = p.num("rent_deduction_share") * pl.col("rentpaid")
        if y == 2001 and not behavior.use_massachusetts_2001_rent_cap_per_statute:
            # TAXSIM keeps the 1997-2000 cap for 2001.
            cap = p.num("taxsim_rent_deduction_cap")
            rnt = pl.min_horizontal(rnt, pl.when(is_sep).then(cap / 2.0).otherwise(cap))
        elif y >= 2001:
            rnt = pl.min_horizontal(rnt, p.num("rent_deduction_cap") / pl.when(is_sep).then(2.0).otherwise(1.0))
        elif y >= 1982:
            rnt = pl.min_horizontal(rnt, p.num("rent_deduction_cap"))
            if p.in_effect("rent_deduction_cap_separate"):
                rnt = pl.when(is_sep).then(
                    pl.min_horizontal(rnt, p.num("rent_deduction_cap_separate"))
                ).otherwise(rnt)
    # Non-property income enters as a negative deduction.
    bded = fica + ch + rnt - pl.col("nonprop")
    if not behavior.leave_massachusetts_part_b_deductions_uncapped_per_statute:
        # TAXSIM allows the deductions only against earned income, interest and pensions (and, from 2022, unemployment).
        # (TAXSIM's earned income also counts the business inputs before 2024 and the non-property input.)
        business_inputs = pl.col("pbusinc") + pl.col("pprofinc") + pl.col("sbusinc") + pl.col("sprofinc") if y < 2024 else pl.lit(0.0)
        allowed = pl.col("earned_income") + business_inputs + pl.col("nonprop") + pl.col("intrec") + pl.col("pensions")
        if y >= 2022:
            allowed = allowed + ui_total
        bded = pl.min_horizontal(fica + ch + rnt, allowed) - pl.col("nonprop")
    df = df.with_columns(
        _ma_binc=binc,
        _ma_bded=bded,
        _ma_exemp=exemp,
        _ma_chcred=chcred,
        _ma_ndep=ndep,
        _ma_b1inc=b1inc,
        _ma_b2inc=b2inc,
    )
    binc = pl.col("_ma_binc")
    bded = pl.col("_ma_bded")
    exemp = pl.col("_ma_exemp")
    chcred = pl.col("_ma_chcred")
    ndep = pl.col("_ma_ndep")
    b1inc = pl.col("_ma_b1inc")
    b2inc = pl.col("_ma_b2inc")
    tbinc1 = (binc - bded).clip(0, None)
    tbinc2 = (tbinc1 - exemp).clip(0, None)

    # --- Part A income ---
    stcg = pl.col("stcg")
    ltcg = pl.col("ltcg")
    divs = pl.col("dividends")
    intrec = pl.col("intrec")
    if y <= 1996:
        gnx = p.num("capital_gains_exclusion")
        if y <= 1982:
            cg = ltcg - (ltcg * gnx).clip(0, None) + stcg
        else:
            cg = (ltcg + stcg) - ((ltcg + stcg) * gnx).clip(0, None)
        cfd = pl.when(cg < 0).then(pl.min_horizontal(pl.lit(float(p["capital_loss_offset_limit"])), -cg)).otherwise(0.0)
        cg = cg.clip(0, None)
        ainc = cg + (intrec + divs - cfd).clip(0, None)
    elif y <= 1998:
        ainc = divs + intrec
    else:
        ainc = stcg.clip(0, None)

    binc_for_agi = binc
    b1_1989 = b2_1989 = None
    if y <= 1988:
        binc_mod = (binc - bded).clip(0, None)
        xtra = (exemp - binc_mod).clip(0, None)
        binc_for_agi = (binc_mod - exemp).clip(0, None)
        ainc = (ainc - x_flag * xtra).clip(0, None)
    elif y == 1989:
        loss1 = b1inc.clip(None, 0)
        loss2 = b2inc.clip(None, 0)
        b1 = (b1inc + loss2).clip(0, None)
        xded = pl.min_horizontal(bded, bded - b1).clip(0, None)
        b1 = (b1 - bded).clip(0, None)
        xex = (exemp - b1).clip(0, None)
        b1 = (b1 - exemp).clip(0, None)
        b2 = (b2inc + loss1).clip(0, None)
        b2 = (b2 - xded).clip(0, None)
        xex2 = (xex - b2).clip(0, None)
        b2 = (b2 - xex).clip(0, None)
        ainc = (ainc - x_flag * xex2).clip(0, None)
        b1_1989, b2_1989 = b1, b2
    elif y <= 1998:
        bagi = binc - bded
        exded = pl.when((bagi < exemp) & not_sep).then(exemp - bagi).otherwise(0.0)
        ainc = (ainc - exded).clip(0, None)

    binc1 = pl.lit(0.0)
    tbinc3 = pl.lit(0.0)
    cinc = pl.lit(0.0)
    if y >= 1999:
        divrec = divs
        capgn = stcg + ltcg
        capgn = pl.when(capgn >= 0).then(capgn).otherwise(
            pl.max_horizontal(capgn, pl.when(is_sep).then(-p["federal_capital_loss_limit"] / 2.0).otherwise(-float(p["federal_capital_loss_limit"])))
        )  # the net gain in federal AGI
        schedule_b_limit = pl.lit(float(p["schedule_b_offset_limit"]))
        xlin4 = (pl.min_horizontal(divrec, schedule_b_limit) - (-stcg.clip(None, 0))).clip(0, None)
        binc1 = pl.when(capgn >= 0).then(divrec).otherwise(divrec - pl.min_horizontal(xlin4, capgn.abs()))
        if y >= 2022 and not behavior.offset_massachusetts_dividends_only_by_losses_per_statute:
            # TAXSIM's 2022 on routine applies the Schedule B offset to a net gain as well.
            binc1 = divrec - pl.min_horizontal(xlin4, capgn.abs())
        excxmp = pl.when((binc - bded < exemp) & not_sep).then(exemp - (binc - bded).clip(0, None)).otherwise(0.0)

        # MA Schedule B (Part 1-4) and Schedule D worksheet, as transcribed.
        xl20 = pl.when(stcg < 0).then(pl.min_horizontal(schedule_b_limit, divrec, -stcg)).otherwise(0.0)
        xl21 = stcg + xl20
        xl22 = pl.when((stcg < 0) & (xl21 < 0) & (ltcg > 0)).then(pl.min_horizontal(-xl21, ltcg)).otherwise(0.0)
        xl24 = stcg.clip(0, None)
        xl25 = pl.when((stcg > 0) & (ltcg < 0)).then(pl.min_horizontal(stcg, -ltcg)).otherwise(0.0)
        xl28 = xl24 - xl25
        xl31 = divrec - xl20
        dxl15 = pl.when(ltcg >= 0).then(ltcg - xl22).otherwise(ltcg + xl22)
        xl32 = pl.when((xl31 > 0) & (dxl15 < 0)).then(
            pl.min_horizontal(
                (pl.min_horizontal(schedule_b_limit, divrec) - xl20).clip(0, None),
                (ltcg - xl22).clip(None, 0).abs(),
            )
        ).otherwise(0.0)
        xl35 = xl31 - xl32 + xl28
        xl37 = (xl35 - excxmp).clip(0, None)
        xl38 = pl.when(xl37 >= divs).then(divrec).otherwise(xl37)
        tbinc3 = xl38
        ainc = xl37 - xl38

        dxl16 = pl.when(dxl15 < 0).then(
            pl.min_horizontal(
                (pl.min_horizontal(divs, schedule_b_limit) - (-stcg.clip(None, 0))).clip(0, None),
                (-ltcg.clip(None, 0)),
            )
        ).otherwise(0.0)
        dxl19 = (dxl16 + dxl15).clip(0, None)
        wdxl1 = xl35.clip(0, None)
        wdxl4 = exemp - tbinc1
        wdxl6 = wdxl4 - pl.min_horizontal(wdxl1, wdxl4)
        dxl20 = pl.when((wdxl4 <= 0) | (wdxl6 <= 0)).then(0.0).otherwise(pl.min_horizontal(dxl19, wdxl6))
        cinc = (dxl19 - dxl20).clip(0, None)
    elif y >= 1997:
        cinc = pl.col("ltg")

    df = df.with_columns(
        _ma_binc_for_agi=binc_for_agi,
        _ma_binc1=binc1,
        _ma_tbinc2=tbinc2,
        _ma_tbinc3=tbinc3,
        _ma_ainc=ainc,
        _ma_cinc=cinc,
    )
    binc_for_agi = pl.col("_ma_binc_for_agi")
    binc1 = pl.col("_ma_binc1")
    tbinc2 = pl.col("_ma_tbinc2")
    tbinc3 = pl.col("_ma_tbinc3")
    ainc = pl.col("_ma_ainc")
    cinc = pl.col("_ma_cinc")

    taxbin = tbinc2 + tbinc3
    rate_b = p.num("part_b_rate")
    if p.in_effect("part_b_rate_first_part"):
        statxb = p.num("part_b_rate_first_part") * b2_1989 + rate_b * b1_1989.clip(0, None)
    else:
        statxb = rate_b * taxbin
    statxa = p.num("part_a_rate") * ainc
    part_c_rate = p.num("part_c_rate") if y >= 1997 else 0.0
    if y == 2020 and not behavior.use_massachusetts_2020_part_c_rate_per_statute:
        # TAXSIM keeps the 2019 long-term gains rate for 2020.
        part_c_rate = p.num("taxsim_part_c_rate")
    statxc = part_c_rate * cinc.clip(0, None) if y >= 1997 else pl.lit(0.0)
    surtax = p.num("surtax")
    if p.in_effect("surtax_income_threshold"):
        threshold = p.num("surtax_income_threshold")
        statxb = pl.when(binc_for_agi > threshold).then(surtax * statxb).otherwise(statxb)
        statxa = pl.when(ainc > threshold).then(surtax * statxa).otherwise(statxa)
        pretax = statxa + statxb
    else:
        pretax = (statxa + statxb + statxc) * surtax
        if p.in_effect("additional_tax"):
            additional = p.value("additional_tax")
            pretax = pretax + float(additional["rate"]) * (
                taxbin + ainc + cinc.clip(0, None) - float(additional["threshold"])
            ).clip(0, None)

    # --- Massachusetts AGI and No Tax Status / Limited Income Credit ---
    ma_agi = (binc_for_agi + pl.col("nonprop") + binc1 + stcg + ltcg + pl.min_horizontal(intrec, p.num("interest_exclusion_per_taxpayer") * n_tp)).clip(0, None)
    df = df.with_columns(_ma_pretax=pretax, _ma_agi=ma_agi)
    pretax = pl.col("_ma_pretax")
    ma_agi = pl.col("_ma_agi")
    ntscr = pl.lit(0.0)
    txcr = pl.lit(0.0)
    scred = pl.lit(0.0)
    if 1984 <= y <= 1994:
        nts1 = p.num("no_tax_status_single")
        nts2 = p.num("no_tax_status_joint")
        s1 = is_single | is_hoh
        ntscr = pl.when(s1 & (ma_agi <= nts1)).then(pretax).when(is_joint & (ma_agi <= nts2)).then(pretax).otherwise(0.0)
        lic_rate = p["limited_income_credit_rate"]
        txcr = (
            pl.when(
                s1 & (ma_agi > nts1) & (ma_agi <= p["limited_income_credit_limit_single"])
                & (pretax >= lic_rate * (ma_agi - nts1))
            )
            .then((pretax - lic_rate * (ma_agi - nts1)).clip(0, None))
            .when(is_joint & (ma_agi > nts2) & (ma_agi <= p.num("limited_income_credit_limit_joint")))
            .then((pretax - lic_rate * (ma_agi - nts2)).clip(0, None))
            .otherwise(0.0)
        )
    elif y >= 1995:
        nts1 = p.num("no_tax_status_single")
        nts2 = p.num("no_tax_status_joint")
        ntsr = pl.when(is_joint).then(nts2 + p.num("no_tax_status_married_addon")).otherwise(nts2)
        licrr = pl.when(is_joint).then(p.num("limited_income_credit_limit_married")).otherwise(
            p.num("limited_income_credit_limit_hoh")
        )
        numdep = pl.col("depx").floor()
        s2 = is_joint | is_hoh
        lo = ntsr + numdep * p["no_tax_status_per_dependent"]
        hi = licrr + numdep * p["limited_income_credit_limit_per_dependent"]
        ntscr = pl.when(is_single & (ma_agi <= nts1)).then(pretax).when(s2 & (ma_agi <= lo)).then(pretax).otherwise(0.0)
        txcr = (
            pl.when(is_single & (ma_agi > nts1) & (ma_agi <= p["limited_income_credit_limit_single"]))
            .then((pretax - p["limited_income_credit_rate"] * (ma_agi - nts1)).clip(0, None))
            .when(s2 & (ma_agi > lo) & (ma_agi <= hi))
            .then((pretax - p["limited_income_credit_rate"] * (ma_agi - lo)).clip(0, None))
            .otherwise(0.0)
        )
    else:
        credit = p.value("personal_credit")
        scred = credit["per_taxpayer"] * n_tp + credit["per_dependent"] * pl.col("depx")

    credit_dependents = ndep
    if y == 2022 and not behavior.cap_massachusetts_2022_household_dependent_credit_per_statute:
        # TAXSIM's 2022 routine pays $180 for every child under 13 (no limit of two, other dependents excluded).
        credit_dependents = pl.col("dep13").floor()
    statax = (pretax - (ntscr + txcr + scred)).clip(0, None)
    if y >= 1997:
        statax = statax - p.num("eitc_rate") * pl.col("eitc")
    if p.in_effect("child_and_family_credit_per_child"):
        statax = statax - p.num("child_and_family_credit_per_child") * pl.col("dep13")
    elif p.in_effect("dependent_credit_per_dependent"):
        statax = statax - pl.max_horizontal(chcred, credit_dependents * p.num("dependent_credit_per_dependent"))

    # Senior circuit breaker credit (2001+, refundable).
    cbcred = pl.lit(0.0)
    if y >= 2001:
        limits = YearParams(MA_PARAMS["circuit_breaker_income_limit"], effective_year)
        hymax = (
            pl.when(is_joint).then(limits.num("married_joint"))
            .when(is_hoh).then(limits.num("head_of_household"))
            .when(is_single).then(limits.num("single"))
            .otherwise(0.0)
        )
        ptax = pl.max_horizontal(pl.col("proptax"), float(MA_PARAMS["circuit_breaker_rent_share"]) * pl.col("rentpaid"))
        hycb = (ma_agi + pl.col("gssi") + pl.col("transfers") - ageex - depex).clip(0, None)
        if not behavior.measure_massachusetts_circuit_breaker_income_per_statute:
            # TAXSIM measures income as federal AGI plus untaxed Social Security and transfers (`hy`).
            hycb = (pl.col("agi") + pl.col("gssi") - pl.col("taxable_social_security") + pl.col("transfers") - ageex - depex).clip(0, None)
        cbcred = pl.when(hycb <= hymax).then((ptax - float(MA_PARAMS["circuit_breaker_income_share"]) * hycb).clip(0, None)).otherwise(0.0)
        cbcred = pl.min_horizontal(cbcred, p.num("circuit_breaker_max"))
        cbcred = pl.when(not_sep & (aged_count() > 0)).then(cbcred).otherwise(0.0)
        statax = statax - cbcred

    earncr = p.num("eitc_rate") * pl.col("eitc") if y >= 1997 else pl.lit(0.0)
    if p.in_effect("child_and_family_credit_per_child"):
        dependent_credit = p.num("child_and_family_credit_per_child") * pl.col("dep13")
        state_chcr = pl.lit(0.0)
    elif p.in_effect("dependent_credit_per_dependent"):
        per_dependent = p.num("dependent_credit_per_dependent")
        dependent_credit = pl.max_horizontal(chcred, credit_dependents * per_dependent)
        state_chcr = pl.when(chcred > credit_dependents * per_dependent).then(chcred).otherwise(0.0)
    else:
        dependent_credit = pl.lit(0.0)
        state_chcr = pl.lit(0.0)
    result = with_state_detail(
        df.with_columns(siitax=statax * flate),
        agi=ma_agi,
        exemptions=exemp,
        taxable_income=taxbin + ainc + cinc - fica,
        child_care_credit=state_chcr,
        eic=earncr,
        credits=ntscr + txcr + scred + earncr + dependent_credit + cbcred,
        rate=rate_b,
    )
    return result.drop(
        "_ma_binc",
        "_ma_bded",
        "_ma_exemp",
        "_ma_chcred",
        "_ma_ndep",
        "_ma_b1inc",
        "_ma_b2inc",
        "_ma_binc_for_agi",
        "_ma_binc1",
        "_ma_tbinc2",
        "_ma_tbinc3",
        "_ma_ainc",
        "_ma_cinc",
        "_ma_pretax",
        "_ma_agi",
    )
