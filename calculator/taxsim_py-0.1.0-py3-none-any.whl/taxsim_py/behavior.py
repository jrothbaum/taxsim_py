"""Calculation modes and the deliberate behavioral differences between them."""


from __future__ import annotations
from dataclasses import dataclass
from enum import Enum


class CalculationMode(str, Enum):
    """Select TAXSIM replication or independently verified statutory corrections."""

    TAXSIM = "taxsim"
    STATUTORY = "statutory"


@dataclass(frozen=True)
class BehaviorProfile:
    """Internal switches for differences documented in statutory_corrections.md."""

    mode: CalculationMode
    coordinate_oasdi_on_net_earnings: bool
    enforce_schedule_se_minimum: bool
    prevent_negative_self_employment_tax: bool
    count_self_employment_once_for_additional_medicare: bool
    include_unemployment_in_california_total_income: bool
    include_business_and_rental_income_in_california_minimum_tax: bool
    count_pre_1998_nonrefundable_credits_correctly: bool
    allow_other_dependent_credit_after_2021: bool
    require_young_child_for_california_yctc: bool
    exclude_hawaii_pensions: bool
    pay_california_yctc_per_young_child: bool
    apply_state_childless_eitc_minimum_age: bool


TAXSIM_BEHAVIOR = BehaviorProfile(
    mode=CalculationMode.TAXSIM,
    coordinate_oasdi_on_net_earnings=False,
    enforce_schedule_se_minimum=False,
    prevent_negative_self_employment_tax=False,
    count_self_employment_once_for_additional_medicare=False,
    include_unemployment_in_california_total_income=False,
    include_business_and_rental_income_in_california_minimum_tax=False,
    count_pre_1998_nonrefundable_credits_correctly=False,
    allow_other_dependent_credit_after_2021=False,
    require_young_child_for_california_yctc=False,
    exclude_hawaii_pensions=False,
    pay_california_yctc_per_young_child=True,
    apply_state_childless_eitc_minimum_age=False,
)

STATUTORY_BEHAVIOR = BehaviorProfile(
    mode=CalculationMode.STATUTORY,
    coordinate_oasdi_on_net_earnings=True,
    enforce_schedule_se_minimum=True,
    prevent_negative_self_employment_tax=True,
    count_self_employment_once_for_additional_medicare=True,
    include_unemployment_in_california_total_income=True,
    include_business_and_rental_income_in_california_minimum_tax=True,
    count_pre_1998_nonrefundable_credits_correctly=True,
    allow_other_dependent_credit_after_2021=True,
    require_young_child_for_california_yctc=True,
    exclude_hawaii_pensions=True,
    pay_california_yctc_per_young_child=False,
    apply_state_childless_eitc_minimum_age=True,
)


def resolve_behavior(mode: str | CalculationMode) -> BehaviorProfile:
    """Return the behavior profile for a public calculation-mode value."""
    try:
        resolved = CalculationMode(mode)
    except (TypeError, ValueError) as exc:
        choices = ", ".join(repr(item.value) for item in CalculationMode)
        raise ValueError(f"calculation_mode must be one of: {choices}") from exc
    return TAXSIM_BEHAVIOR if resolved is CalculationMode.TAXSIM else STATUTORY_BEHAVIOR
