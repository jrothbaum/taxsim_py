"""Federal individual income tax calculator for 1977 through 1986."""


from __future__ import annotations
import polars as pl

from taxsim_py.behavior import BehaviorProfile, TAXSIM_BEHAVIOR
from taxsim_py.engine.brackets import bracket_rate_by_status, bracket_tax_by_status
from taxsim_py.engine.eitc import trapezoid_credit
from taxsim_py.engine.inputs import aged_count, files_joint, files_separate, filing_status, is_dependent_filer, taxpayer_count
from taxsim_py.engine.schema import PARAMETERS_ROOT, YearParams, load_yaml, resolve_year
from taxsim_py.engine.state import FORCE_ITEMIZE, by_filing_status, dividend_input_adjustment, federal_dividend_exclusion_limit, itemize_choice, unemployment_total, with_default

PRE1987_PARAMS = load_yaml(PARAMETERS_ROOT / "national" / "pre1987.yaml")
SOCIAL_SECURITY_PARAMS = load_yaml(PARAMETERS_ROOT / "national" / "social_security.yaml")
ANALYTIC_RATE_PARAMS = load_yaml(PARAMETERS_ROOT / "national" / "analytic_rate.yaml")

FILING_STATUSES = ["single", "married_joint", "married_separate", "head_of_household"]
SEPRET_BY_STATUS = {
    "single": 1.0,
    "married_joint": 1.0,
    "head_of_household": 1.0,
    "married_separate": 2.0,
}


def compute_federal_income_tax_pre1987(
    df: pl.DataFrame | pl.LazyFrame,
    year: int,
    behavior: BehaviorProfile = TAXSIM_BEHAVIOR,
) -> pl.DataFrame | pl.LazyFrame:
    p = YearParams(PRE1987_PARAMS, year)
    # Working columns vary by year, so the output keeps the input columns
    # and a fixed result set.
    original_columns = (
        df.collect_schema().names() if isinstance(df, pl.LazyFrame) else list(df.columns)
    )
    df = df.with_columns(
        filing_status=filing_status(),
        wages=pl.col("pwages") + pl.col("swages"),
    )
    if FORCE_ITEMIZE not in (df.collect_schema().names() if isinstance(df, pl.LazyFrame) else df.columns):
        df = df.with_columns(pl.lit(None).alias(FORCE_ITEMIZE))
    for col in (
        "proptax", "otheritem", "mortgage", "intrec", "psemp", "ssemp", "dividends", "stcg", "ltcg", "ui",
        "pui", "sui", "state_sales_or_income_tax_ded", "pensions", "gssi", "otherprop", "nonprop", "page", "sage",
        "pbusinc", "pprofinc", "sbusinc", "sprofinc", "scorp",
    ):
        df = with_default(df, col)
    # Unemployment compensation as TAXSIM combines it (`data(82)`).
    df = df.with_columns(ui_combined=unemployment_total())

    sepret_expr = by_filing_status(SEPRET_BY_STATUS)
    brackets_by_status = {status: resolve_year(p["brackets"][status], year) for status in FILING_STATUSES}

    gross_se_income = pl.col("psemp") + pl.col("ssemp")
    if behavior.include_business_income_before_1987:
        gross_se_income = gross_se_income + pl.col("pbusinc") + pl.col("pprofinc") + pl.col("sbusinc") + pl.col("sprofinc")
    df = df.with_columns(sepret=sepret_expr, gross_se_income=gross_se_income)
    df = df.with_columns(earned=(pl.col("wages") + pl.col("gross_se_income")).clip(0, None))

    # Dividend exclusion (`divall`); 1981 also excludes interest.
    divexc_expr = federal_dividend_exclusion_limit(year, behavior)
    df = df.with_columns(dividends_with_fudge=pl.col("dividends") + dividend_input_adjustment(), divexc=divexc_expr)
    if year == 1981:
        df = df.with_columns(
            divall=(pl.col("dividends_with_fudge") + pl.col("intrec") - pl.col("divexc")).clip(0, None),
            ints=pl.lit(0.0),
        )
    else:
        df = df.with_columns(
            divall=(pl.col("dividends_with_fudge") - pl.col("divexc")).clip(0, None),
            ints=pl.col("intrec"),
        )

    # Capital gains: part of a net long-term gain is excluded (`capded`).
    # A net loss counts short-term losses in full and long-term losses at
    # `long_term_loss_share`, limited per return and by other income below.
    caprat = p.num("capital_gains_exclusion_rate")
    lt_loss_share = p.num("long_term_loss_share")
    loss_limit = p.num("net_capital_loss_limit")
    stcg = pl.col("stcg")
    ltcg = pl.col("ltcg")
    df = df.with_columns(fullcg=stcg + ltcg)
    df = df.with_columns(capded=(caprat * pl.min_horizontal(ltcg, pl.col("fullcg"))).clip(0, None))
    net_loss = (
        pl.when(ltcg >= 0)
        .then(pl.col("fullcg"))
        .when(stcg >= 0)
        .then(lt_loss_share * pl.col("fullcg"))
        .otherwise(stcg + lt_loss_share * ltcg)
    )
    df = df.with_columns(
        capgn=pl.when(pl.col("fullcg") > 0)
        .then(pl.col("fullcg") - pl.col("capded"))
        .otherwise(pl.max_horizontal(net_loss, -loss_limit / pl.col("sepret")))
    )

    # Two-earner deduction: a share of the lower earner's wages, capped.
    if p.in_effect("two_earner_deduction_rate"):
        two_earner_rate = p.num("two_earner_deduction_rate")
        two_earner_cap = p.num("two_earner_deduction_cap")
        df = df.with_columns(wife=pl.min_horizontal(pl.col("pwages"), pl.col("swages")).clip(0, None))
        df = df.with_columns(
            twoded=pl.when(files_joint())
            .then((two_earner_rate * pl.col("wife")).clip(0, two_earner_cap))
            .otherwise(0.0)
        )
    else:
        df = df.with_columns(twoded=pl.lit(0.0))

    # Pensions and other property income are income; other non-property
    # income enters through the adjustments. TAXSIM does not read business
    # income or S corporation income.
    scorp = pl.col("scorp") if behavior.include_business_income_before_1987 else pl.lit(0.0)
    df = df.with_columns(
        ti=pl.col("divall") + pl.col("wages") + pl.col("ints") + pl.col("gross_se_income")
        + pl.col("pensions") + pl.col("otherprop") + scorp,
    )
    # A net capital loss cannot exceed other income.
    df = df.with_columns(capgn=pl.max_horizontal(pl.col("capgn"), -pl.col("ti").clip(0, None)))
    df = df.with_columns(
        agi_pre_ui=pl.col("ti") - pl.col("twoded") + pl.col("nonprop") + pl.col("capgn"),
        unearned=pl.col("ti") - pl.col("earned") + pl.col("capgn"),
    )

    # Unemployment compensation: half the excess over a threshold is
    # taxable, up to the benefit.
    if not p.in_effect("unemployment_exclusion_threshold"):
        df = df.with_columns(untax=pl.lit(0.0))
    else:
        uxemp_expr = by_filing_status(p.value("unemployment_exclusion_threshold"))
        df = df.with_columns(uxemp=uxemp_expr)
        df = df.with_columns(
            untax=pl.min_horizontal(
                (0.5 * (pl.col("ui_combined") + pl.col("agi_pre_ui") - pl.col("uxemp")).clip(0, None)),
                pl.col("ui_combined"),
            )
        )
    df = df.with_columns(
        taxable_unemployment=pl.col("untax"),
        agi=pl.col("agi_pre_ui") + pl.col("untax"),
    )
    # From 1984, half of Social Security benefits above the base amount.
    if year >= 1984:
        ss_p = SOCIAL_SECURITY_PARAMS
        benefits = pl.col("gssi").clip(0, None)
        over_base = (
            pl.col("agi") + 0.5 * benefits + pl.col("twoded") - by_filing_status(ss_p["base_amount"])
        ).clip(0, None)
        taxable_ss = pl.when(benefits > 0).then(
            ss_p["first_tier_rate"] * pl.min_horizontal(benefits, over_base)
        ).otherwise(0.0)
        # Benefits are in the phase-in: another dollar of income raises the
        # taxable amount.
        ss_phasing = (taxable_ss > 0) & (benefits > over_base)
    else:
        taxable_ss = pl.lit(0.0)
        ss_phasing = pl.lit(False)
    df = df.with_columns(taxable_social_security=taxable_ss, ss_phasing=ss_phasing)
    df = df.with_columns(agi=pl.col("agi") + pl.col("taxable_social_security"))

    # Itemized deduction: property and other taxes, mortgage interest and
    # the state income or sales tax deduction (`data(50)`).
    zbr_expr = by_filing_status({status: resolve_year(p["standard_deduction"][status], year) for status in FILING_STATUSES})
    df = df.with_columns(
        deduc=pl.col("proptax") + pl.col("otheritem") + pl.col("mortgage") + pl.col("state_sales_or_income_tax_ded"),
        zbr=zbr_expr,
    )
    # From 1982 a forced choice (`data(4)`) overrides itemizing; through 1981
    # itemizing is always `deduc>zbr`.
    if year <= 1981:
        itemizes_expr = pl.col("deduc") > pl.col("zbr")
    else:
        itemizes_expr = itemize_choice(pl.col("deduc") > pl.col("zbr"))
    df = df.with_columns(itemizes=itemizes_expr)
    df = df.with_columns(excess=pl.when(pl.col("itemizes")).then(pl.col("deduc") - pl.col("zbr")).otherwise(0.0))

    exemption_amount = p.num("personal_exemption_amount")
    # Taxpayers (none for a dependent filer), dependents and one more for
    # each taxpayer 65 or older.
    df = df.with_columns(exemps_count=taxpayer_count() + pl.col("depx") + aged_count())
    df = df.with_columns(amex=exemption_amount * pl.col("exemps_count"))
    # A dependent filer with $1,000 of unearned income who itemizes adds
    # back the standard deduction not covered by earnings or deductions.
    df = df.with_columns(
        add105=pl.when(is_dependent_filer() & (pl.col("unearned") >= 1000) & pl.col("itemizes"))
        .then((pl.col("zbr") - pl.max_horizontal(pl.col("earned"), pl.col("deduc"))).clip(0, None))
        .otherwise(0.0)
    )
    df = df.with_columns(taxy=pl.col("agi") - pl.col("excess") - pl.col("amex") + pl.col("add105"))
    if year <= 1978:
        df = df.with_columns(taxable_income_for_bracket=(pl.col("taxy") - pl.col("zbr")).clip(0, None))
    else:
        df = df.with_columns(taxable_income_for_bracket=pl.col("taxy").clip(0, None))
    # `taxinc` and `taxy` stay unclipped for the alternative and minimum
    # taxes; only the bracket lookup clips at 0.
    df = df.with_columns(
        taxinc_unclamped=pl.col("taxy") - pl.col("zbr"),
        regtax_raw=bracket_tax_by_status(pl.col("taxable_income_for_bracket"), brackets_by_status),
    )
    rrc = p.num("rate_reduction_credit_multiplier") if p.in_effect("rate_reduction_credit_multiplier") else 1.0
    df = df.with_columns(regtax=rrc * pl.col("regtax_raw") if rrc != 1.0 else pl.col("regtax_raw"))

    # --- Alternative computation of tax on capital gains (`acgtax`) ---
    alt = p.value("alternative_capital_gains") if p.in_effect("alternative_capital_gains") else {}
    if "threshold" in alt:
        threshold = float(alt["threshold"])
        df = df.with_columns(cg1=(pl.col("taxinc_unclamped") - pl.col("capded")).clip(0, None))
        df = df.with_columns(
            cgtx1=bracket_tax_by_status(pl.col("cg1"), brackets_by_status),
            subd=(threshold / pl.col("sepret")).clip(0, None),
            gated=pl.col("capded") * 2 > (threshold / pl.col("sepret")),
        )
        df = df.with_columns(further_gated=pl.col("gated") & (pl.col("subd") < pl.col("capded") * 2))
        df = df.with_columns(
            cgtx2=pl.when(pl.col("further_gated")).then(alt["subd_rate"] * pl.col("subd")).otherwise(
                alt["capded_rate"] * pl.col("capded")
            ),
            cg3=pl.max_horizontal(pl.col("taxinc_unclamped"), pl.col("capded")),
        )
        df = df.with_columns(
            cgtx31=bracket_tax_by_status(pl.col("cg3"), brackets_by_status),
            cg1_plus_half_subd=pl.col("cg1") + pl.col("subd") * 0.5,
        )
        df = df.with_columns(cgtx32=bracket_tax_by_status(pl.col("cg1_plus_half_subd"), brackets_by_status))
        df = df.with_columns(
            cgtx3=pl.when(pl.col("further_gated")).then(pl.col("cgtx31") - pl.col("cgtx32")).otherwise(0.0)
        )
        df = df.with_columns(
            acgtax=pl.when(pl.col("fullcg") > 0)
            .then(pl.col("cgtx1") + pl.col("cgtx2") + pl.col("cgtx3"))
            .otherwise(-1.0)
        )
    elif alt:
        df = df.with_columns(cglong=pl.min_horizontal(pl.col("ltcg"), pl.col("fullcg")).clip(0, None))
        df = df.with_columns(cg1=(pl.col("taxy") - alt["excluded_share"] * pl.col("cglong")).clip(0, None))
        df = df.with_columns(cgtx1_raw=bracket_tax_by_status(pl.col("cg1"), brackets_by_status))
        df = df.with_columns(
            acgtax=pl.when(pl.col("cglong") > 0)
            .then(rrc * pl.col("cgtx1_raw") + alt["rate"] * pl.col("cglong"))
            .otherwise(-1.0)
        )
    else:
        df = df.with_columns(acgtax=pl.lit(-1.0))

    # --- Maximum tax on earned income (`etax`) ---
    if p.in_effect("max_tax_earned_income_floor"):
        ebot_expr = by_filing_status(p.value("max_tax_earned_income_floor"))
        eacc_expr = by_filing_status(p.value("max_tax_earned_income_accumulated"))
        df = df.with_columns(
            ebot=ebot_expr,
            eacc=eacc_expr,
            psinc=pl.when(pl.col("agi") != 0).then((pl.col("earned") + pl.col("pensions")).clip(0, pl.col("agi"))).otherwise((pl.col("earned") + pl.col("pensions"))),
        )
        df = df.with_columns(
            eratio=pl.when(pl.col("agi") == 0).then(1.0).otherwise((pl.col("psinc") / pl.col("agi")).clip(None, 1.0))
        )
        # Preference income (`pref`) for `eti`: in 1977-1978 itemizers add
        # back excluded gains, unemployment compensation, wages and excess
        # itemized deductions; 1979-1981 read `data(164)`, which is 0.
        if year <= 1978:
            df = df.with_columns(
                exded_pref=pl.min_horizontal(
                    (pl.col("deduc") - p["excess_itemized_preference"]["agi_floor_share"] * pl.col("agi")).clip(0, None),
                    p["excess_itemized_preference"]["cap_share"] * pl.col("agi"),
                )
            )
            # TAXSIM also counts wages and unemployment compensation.
            misread = 0.0 if behavior.exclude_wages_from_1977_preference_income else pl.col("ui_combined") + pl.col("wages")
            df = df.with_columns(
                pref=pl.when(pl.col("itemizes"))
                .then((pl.col("capded") + misread + pl.col("exded_pref")).clip(0, None))
                .otherwise(0.0)
            )
            df = df.with_columns(eti=pl.col("taxinc_unclamped") * pl.col("eratio") - pl.col("pref"))
        else:
            df = df.with_columns(eti=pl.col("taxy") * pl.col("eratio"))
        df = df.with_columns(
            etop=pl.col("eti") - pl.col("ebot"),
            partax=bracket_tax_by_status(pl.col("eti"), brackets_by_status),
        )
        if rrc != 1.0:
            df = df.with_columns(
                etax_raw=rrc * (pl.col("regtax_raw") - pl.col("partax") + pl.col("eacc")) + 0.5 * pl.col("etop")
            )
        else:
            df = df.with_columns(
                etax_raw=pl.col("regtax") - pl.col("partax") + pl.col("eacc") + 0.5 * pl.col("etop")
            )
        df = df.with_columns(
            etax_eligible=(pl.col("sepret") == 1.0) & (pl.col("agi") > 0) & (pl.col("psinc") > 0) & (pl.col("etop") > 0)
        )
        df = df.with_columns(etax=pl.when(pl.col("etax_eligible")).then(pl.col("etax_raw")).otherwise(-1.0))
    else:
        df = df.with_columns(etax=pl.lit(-1.0))

    # --- Combine alternatives: taxbc = min(regular, acgtax, etax) ---
    df = df.with_columns(
        taxbc=pl.when(pl.col("acgtax") > 0).then(pl.min_horizontal(pl.col("acgtax"), pl.col("regtax"))).otherwise(pl.col("regtax"))
    )
    df = df.with_columns(
        taxbc=pl.when((pl.col("etax") > 0) & (pl.col("etax") < pl.col("taxbc"))).then(pl.col("etax")).otherwise(pl.col("taxbc"))
    )

    # --- Child and Dependent Care Credit (only nonrefundable credit in scope) ---
    expense_cap = p.num("child_care_credit_expense_cap")
    df = df.with_columns(
        chmax=expense_cap * pl.col("dep13").clip(0, 2),
        chwage=pl.col("wages").clip(0, None),
    )
    df = df.with_columns(child_expense=pl.min_horizontal(pl.col("chmax"), pl.col("chwage"), pl.col("childcare")))
    ccc = p.value("child_care_credit_rate")
    if not isinstance(ccc, dict):
        df = df.with_columns(ccc_rate=pl.lit(float(ccc)))
    else:
        df = df.with_columns(
            ccc_rate=(
                ccc["max_rate"] - ((pl.col("agi") - ccc["agi_floor"]) / ccc["agi_step"]).clip(0, None)
            ).clip(ccc["min_rate"], None)
        )
    df = df.with_columns(chcr=pl.col("child_expense") * pl.col("ccc_rate"))

    # General tax credit.
    if p.in_effect("general_tax_credit"):
        gtc = p.value("general_tax_credit")
        gencr = pl.max_horizontal(
            gtc["per_exemption"] * pl.col("exemps_count"),
            pl.min_horizontal(float(gtc["maximum"]), gtc["taxable_income_rate"] * pl.col("taxable_income_for_bracket")),
        )
    else:
        gencr = pl.lit(0.0)
    df = df.with_columns(gencr=gencr)

    # Credit for the elderly; TAXSIM caps it at an input it never sets, so 0.
    if behavior.apply_elderly_credit_before_1987:
        eld_p = YearParams(p["elderly_credit"], year)
        base = eld_p.value("base")
        threshold = eld_p.value("agi_threshold")
        one_aged = (aged_count() == 1) & ~files_separate()
        two_aged_base = pl.lit(float(base["two_aged"])) / pl.col("sepret")
        base_amount = pl.when(one_aged).then(float(base["one_aged"])).otherwise(two_aged_base)
        single = ~files_joint() & ~files_separate()
        agi_threshold = pl.when(single).then(float(threshold["one_aged"])).otherwise(
            pl.lit(float(threshold["two_aged"])) / pl.col("sepret")
        )
        reduction = eld_p.num("agi_share") * (pl.col("agi") - agi_threshold).clip(0, None) + (
            pl.col("gssi") - pl.col("taxable_social_security")
        ).clip(0, None)
        elderly = pl.when(aged_count() > 0).then(eld_p.num("rate") * (base_amount - reduction).clip(0, None)).otherwise(0.0)
    else:
        elderly = pl.lit(0.0)
    df = df.with_columns(credit=pl.min_horizontal(pl.col("chcr") + pl.col("gencr") + elderly, pl.col("taxbc")).clip(0, None))
    df = df.with_columns(taxaft=pl.col("taxbc") - pl.col("credit"))

    # --- Minimum tax: three distinct formulas layered as a floor over taxaft ---
    if year <= 1978:
        df = df.with_columns(mintax_raw=pl.lit(-1.0))  # inert - no mechanism reaches `tax` at all
    elif year <= 1981:
        t1 = p.num("minimum_tax_tier1_threshold")
        t2 = p.num("minimum_tax_tier2_threshold")
        t3 = p.num("minimum_tax_tier3_threshold")
        r1 = p.num("minimum_tax_tier1_rate")
        r2 = p.num("minimum_tax_tier2_rate")
        r3 = p.num("minimum_tax_tier3_rate")
        # `alminy = agi - amex - excess - zbr + capded`; from 1979 `taxy`
        # excludes `zbr` once more.
        df = df.with_columns(alminy=pl.col("taxinc_unclamped") + pl.col("capded"))
        df = df.with_columns(
            mintax_raw=(
                r1 * (pl.col("alminy") - t1 / pl.col("sepret")).clip(0, None)
                + r2 * (pl.col("alminy") - t2 / pl.col("sepret")).clip(0, None)
                + r3 * (pl.col("alminy") - t3 / pl.col("sepret")).clip(0, None)
            )
        )
    elif year == 1982:
        t1 = p.num("minimum_tax_tier1_threshold")
        t2 = p.num("minimum_tax_tier2_threshold")
        r1 = p.num("minimum_tax_tier1_rate")
        r2 = p.num("minimum_tax_tier2_rate")
        # The excess-itemized-deduction preference leaves state income tax
        # out of both the deductions and AGI.
        salt = pl.col("state_sales_or_income_tax_ded")
        prfded = (pl.col("deduc") - salt).clip(0, None)
        prfddy = (pl.col("agi") - salt).clip(0, None)
        df = df.with_columns(
            exded_1979plus=pl.when(pl.col("itemizes"))
            .then((prfded - p["excess_itemized_preference"]["agi_floor_share"] * prfddy).clip(0, None))
            .otherwise(0.0)
        )
        df = df.with_columns(
            alminy=pl.col("agi") - pl.col("excess") - pl.col("zbr") - pl.col("amex") + pl.col("capded") + pl.col("exded_1979plus")
        )
        df = df.with_columns(
            mintax_raw=r1 * (pl.col("alminy") - t1 / pl.col("sepret")).clip(0, None)
            + r2 * (pl.col("alminy") - t2 / pl.col("sepret")).clip(0, None)
        )
    else:  # 1983-1986
        flat_rate = p.num("minimum_tax_flat_rate")
        offset_single_hoh = p.num("minimum_tax_offset_single_hoh")
        offset_joint_sep = p.num("minimum_tax_offset_joint_sep")
        df = df.with_columns(
            offset=pl.when(pl.col("filing_status").is_in(["single", "head_of_household"]))
            .then(offset_single_hoh)
            .otherwise(offset_joint_sep / pl.col("sepret"))
        )
        # Medical, charitable, casualty and housing interest deductions reduce
        # this base; TAXSIM omits housing interest.
        pref = pl.when(pl.col("fullcg") < 0).then(pl.col("fullcg") - pl.col("capgn")).otherwise(pl.col("capded"))
        housing = pl.lit(0.0)
        if behavior.deduct_mortgage_interest_from_1983_minimum_tax:
            housing = pl.when(pl.col("itemizes")).then(pl.col("mortgage")).otherwise(0.0)
        df = df.with_columns(alminy=(pl.col("agi") + pref - housing).clip(0, None))
        df = df.with_columns(mintax_raw=flat_rate * (pl.col("alminy") - pl.col("offset")).clip(0, None))

    df = df.with_columns(
        tax_after_mintax=pl.when(pl.col("mintax_raw") > 0)
        .then(pl.max_horizontal(pl.col("taxaft"), pl.col("mintax_raw")))
        .otherwise(pl.col("taxaft"))
    )

    # --- EITC (own early rate schedule - a single flat table, not varying
    # by status or number of children, only by eligibility) ---
    rate_in = p.num("eitc_rate_in")
    max_credit = p.num("eitc_max_credit")
    phaseout_start = p.num("eitc_phaseout_start")
    rate_out = p.num("eitc_rate_out")
    df = df.with_columns(
        earncr_raw=trapezoid_credit(pl.col("earned"), pl.col("agi"), rate_in, max_credit, phaseout_start, rate_out)
    )
    df = df.with_columns(
        earncr=pl.when((files_separate()) | (pl.col("dep18") == 0) | is_dependent_filer())
        .then(0.0)
        .otherwise(pl.col("earncr_raw"))
    )

    # TAXSIM's shared `rate` (`comnew(72)`) is a hand-coded analytic rate,
    # not the finite-difference `frate`. Several states consume this value.
    regrat = bracket_rate_by_status(pl.col("taxable_income_for_bracket"), brackets_by_status)
    # TAXSIM overwrites the 1981 rate-reduction factor on the next line.
    rgrate = 100.0 * regrat * (rrc if behavior.correct_analytic_federal_rate else 1.0)
    a = ANALYTIC_RATE_PARAMS
    ui_share = a["partial_unemployment_share"]
    ss_share = a["social_security_first_tier_share"]
    partial_ui = (pl.col("untax") > 0) & (pl.col("untax") < pl.col("ui_combined"))
    pssa = pl.col("ss_phasing")
    rate = rgrate + pl.when(partial_ui).then(ui_share * rgrate).otherwise(0.0) + pl.when(pssa).then(ss_share * rgrate).otherwise(0.0)

    if year <= 1981:
        acg_selected = (pl.col("acgtax") > 0) & (pl.col("acgtax") < pl.col("regtax")) & ~(
            (pl.col("etax") > 0) & (pl.col("etax") < pl.col("acgtax"))
        )
        etax_selected = (pl.col("etax") > 0) & (pl.col("etax") < pl.col("regtax")) & (
            (pl.col("acgtax") <= 0) | (pl.col("etax") < pl.col("acgtax"))
        )
        # The alternative-tax rate (`garb`) is set only where the 1977-1978
        # computation reaches its second bracket lookup; otherwise it is 0.
        if year <= 1978:
            # Below the gated range the ordinary rate applies to `cg1`;
            # TAXSIM leaves it 0.
            moderate = (
                100.0 * bracket_rate_by_status(pl.col("cg1"), brackets_by_status)
                if behavior.correct_analytic_federal_rate
                else 0.0
            )
            cg_rate = pl.when(pl.col("further_gated")).then(
                100.0 * bracket_rate_by_status(pl.col("cg3"), brackets_by_status)
            ).otherwise(moderate)
        elif year == 1981:
            cg_rate = 100.0 * bracket_rate_by_status(pl.col("cg1"), brackets_by_status)
        else:
            cg_rate = pl.lit(0.0)
        rate = pl.when(acg_selected).then(
            cg_rate * (1.0 + pl.when(partial_ui).then(ui_share).otherwise(0.0))
        ).otherwise(rate)
        part_rate = bracket_rate_by_status(pl.col("eti"), brackets_by_status)
        taxinc = pl.col("taxinc_unclamped").clip(0, None)
        retax = 100.0 * (
            regrat - part_rate + 0.5
            + (part_rate - 0.5) * (pl.col("agi") - pl.col("psinc")) * (pl.col("agi") - taxinc)
            / (pl.col("agi") * pl.col("agi"))
        )
        rate = pl.when(etax_selected & (pl.col("agi") > 0)).then(retax).otherwise(rate)

    # Child care credit: the AGI-scaled credit rate's slope while it phases
    # down, or minus the credit rate while expenses are limited by earnings.
    has_child = pl.col("child_expense") > 0
    ccc_rate = pl.col("ccc_rate")
    floor, top = a["law79_child_care_rate_floor"], a["law79_child_care_rate_top"]
    rchild = pl.when(has_child & (ccc_rate > floor) & (ccc_rate < top)).then(
        pl.col("child_expense") / a["law79_child_care_slope_divisor"]
    ).otherwise(0.0)
    earnings_limited = has_child & (pl.col("chwage") < pl.col("chmax")) & (pl.col("chwage") < pl.col("childcare"))
    rchild = pl.when(earnings_limited).then(
        pl.when(ccc_rate < top).then(-(rchild + a["law79_child_care_low_rate_points"])).otherwise(
            -a["law79_child_care_high_rate_points"]
        )
    ).otherwise(rchild)
    rate = rate + rchild

    rate = pl.when(pl.col("taxbc") <= pl.col("credit")).then(0.0).otherwise(rate)
    # EITC marginal component (`reic`), including its AGI/earned-income
    # phaseout choice. This deliberately follows TAXSIM's analytic formula.
    in_phase_in = (pl.col("earncr") > 0) & (pl.col("earncr") < max_credit)
    above_plateau = (pl.col("agi") > phaseout_start) | (pl.col("earned") > phaseout_start)
    ncr = pl.col("earncr_raw") < max_credit
    reic = pl.when(in_phase_in).then(-rate_in).otherwise(0.0)
    phase_rate = pl.when(ncr).then(-rate_in + rate_out).otherwise(rate_out)
    phase_rate = pl.when(pl.col("agi") > pl.col("earned")).then(
        phase_rate * (1.0 + ui_share * partial_ui.cast(pl.Float64) + ss_share * pssa.cast(pl.Float64))
    ).otherwise(phase_rate)
    reic = pl.when(in_phase_in & above_plateau).then(phase_rate).otherwise(reic) * 100.0
    rate = pl.when(pl.col("credit") < pl.col("taxbc")).then(rate + reic).otherwise(reic)

    # When the minimum tax controls, TAXSIM replaces the regular rate with
    # the minimum-tax rate plus the EITC component. The zero-bracket amount
    # is always positive, which zeroes the 1979-1981 rate and nets the 1982
    # rate down to its excess-deduction term.
    amt_controls = pl.col("tax_after_mintax") > pl.col("taxaft")
    if year <= 1978:
        almrat = pl.lit(0.0)
    elif year <= 1982:
        def tier(n: int) -> pl.Expr:
            threshold = p.num(f"minimum_tax_tier{n}_threshold")
            rate_n = p.num(f"minimum_tax_tier{n}_rate")
            return rate_n * (pl.col("alminy") > threshold / pl.col("sepret")).cast(pl.Float64)

        almr = tier(1) + tier(2)
        if p.in_effect("minimum_tax_tier3_threshold"):
            almrat = almr + tier(3)
        else:
            # The excess itemized deduction preference nets the rate down.
            salt = pl.col("state_sales_or_income_tax_ded")
            pexded = (pl.col("exded_1979plus") > 0) & ((pl.col("agi") - salt).clip(0, None) > 0)
            share = p.num("minimum_tax_excess_itemized_share")
            almrat = almr * (1.0 - share * pexded.cast(pl.Float64))
            if not behavior.correct_analytic_federal_rate:
                almrat = almrat - almr
    else:
        flat = p.num("minimum_tax_flat_rate")
        almrat = pl.when(pl.col("itemizes")).then(flat).otherwise(0.0)
    ralm = almrat * (1.0 + ss_share * pssa.cast(pl.Float64)) * 100.0
    if year <= 1981 and not behavior.correct_analytic_federal_rate:
        amt_rate = pl.when(in_phase_in).then(reic).otherwise(0.0)
    else:
        amt_rate = ralm + reic
    rate = pl.when(amt_controls).then(amt_rate).otherwise(rate)
    rate = pl.when(amt_controls & partial_ui & (pl.col("agi") > 0)).then((1.0 + ui_share) * ralm).otherwise(rate)
    df = df.with_columns(
        federal_source_rate=rate,
        fiitax=pl.col("tax_after_mintax") - pl.col("earncr"),
        taxable_income=pl.col("taxable_income_for_bracket"),
        earned_income=pl.col("earned"),
        regular_tax=pl.col("regtax"),
        pre1987_taxbc=pl.col("taxbc"),
        pre1987_chcr=pl.col("chcr"),
        federal_chcr=pl.col("chcr"),
        pre1987_earncr=pl.col("earncr"),
        pre1987_almtax=pl.col("tax_after_mintax") - pl.col("taxaft"),
        pre1987_capgn=pl.col("capgn"),
        pre1987_capded=pl.col("capded"),
        pre1987_twoded=pl.col("twoded"),
    )
    # Detail-output figures; the early law has no minimum-tax income.
    present = set(df.collect_schema().names())
    df = df.with_columns(
        *[
            (pl.col(name) if name in present else pl.lit(0.0)).alias(f"pre1987_{name}")
            for name in ("zbr", "amex", "gencr", "alminy")
        ],
    )
    # The itemize flag (`comnew(26)`) and itemized deductions as states read
    # them: itemizing is dropped when it leaves no taxable income and
    # income is within exemptions and the zero-bracket amount.
    no_benefit = (pl.col("taxinc_unclamped") <= 0) & (pl.col("agi") - pl.col("amex") - pl.col("zbr") <= 0)
    df = df.with_columns(pre1987_itemizes=pl.col("itemizes") & ~no_benefit)
    df = df.with_columns(
        pre1987_deduc=pl.when(pl.col("pre1987_itemizes")).then(pl.col("deduc")).otherwise(0.0),
        pre1987_taxinc=pl.col("taxinc_unclamped").clip(0, None),
    )
    # Federal preference income (`pref`) as the state calculators read it.
    if year <= 1978:
        pref_out = pl.col("pref")
    elif year <= 1982:
        pref_out = pl.lit(0.0)
    else:
        pref_out = pl.when(pl.col("fullcg") < 0).then(pl.col("fullcg") - pl.col("capgn")).otherwise(pl.col("capded"))
    df = df.with_columns(pre1987_pref=pref_out)
    # `pretax`: the largest of the tax measures, with final tax counting only
    # the part of the earned income credit that offsets tax.
    eitc_offset = pl.min_horizontal(pl.col("earncr"), pl.col("tax_after_mintax").clip(0, None))
    df = df.with_columns(
        pre1987_pretax=pl.max_horizontal(
            pl.col("regtax"),
            pl.col("taxbc"),
            pl.col("pre1987_almtax"),
            pl.col("tax_after_mintax") - pl.col("earncr") + eitc_offset + pl.col("credit"),
        )
    )
    result_columns = [
        "filing_status",
        "wages",
        "agi",
        "taxable_unemployment",
        "taxable_social_security",
        "taxable_income",
        "earned_income",
        "regular_tax",
        "fiitax",
        "credit",
        "pre1987_taxbc",
        "pre1987_chcr",
        "federal_chcr",
        "pre1987_earncr",
        "pre1987_almtax",
        "pre1987_pretax",
        "pre1987_capgn",
        "pre1987_capded",
        "pre1987_pref",
        "pre1987_twoded",
        "pre1987_zbr",
        "pre1987_amex",
        "pre1987_deduc",
        "pre1987_gencr",
        "pre1987_alminy",
        "pre1987_taxinc",
        "pre1987_itemizes",
        "federal_source_rate",
    ]
    return df.select([*original_columns, *result_columns])
